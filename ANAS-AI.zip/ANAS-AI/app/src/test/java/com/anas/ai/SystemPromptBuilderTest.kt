package com.anas.ai

import com.anas.ai.core.Personality
import com.anas.ai.core.SystemPromptBuilder
import org.junit.Assert.assertTrue
import org.junit.Test

class SystemPromptBuilderTest {
    @Test fun banglaDefaultInEveryPersonality() {
        Personality.entries.forEach {
            val p = SystemPromptBuilder.build(it, accessibilityOn = true, rootOn = false)
            assertTrue(p.contains("ডিফল্ট ভাষা বাংলা"))
            assertTrue(p.contains("Hinglish"))
        }
    }

    @Test fun rootWarningWhenUnavailable() {
        val p = SystemPromptBuilder.build(Personality.ASSISTANT, accessibilityOn = false, rootOn = false)
        assertTrue(p.contains("Root ব্যবহারযোগ্য নয়"))
    }
}
