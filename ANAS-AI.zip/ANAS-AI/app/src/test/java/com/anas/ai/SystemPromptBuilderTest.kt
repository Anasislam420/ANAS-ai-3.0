package com.anas.ai

import com.anas.ai.core.Personality
import com.anas.ai.core.SystemPromptBuilder
import org.junit.Assert.assertTrue
import org.junit.Test

class SystemPromptBuilderTest {
    @Test fun banglaDefaultInEveryPersonality() {
        Personality.entries.forEach {
            val p = SystemPromptBuilder.build(it, accessibilityOn = true, rootOn = false)
            assertTrue(p.contains("ডিফল্ট ভাষা বাংলা"))
            assertTrue(p.contains("Hinglish"))
        }
    }

    @Test fun girlfriendModeIsAffectionateButSafe() {
        val p = SystemPromptBuilder.build(Personality.GIRLFRIEND, accessibilityOn = false, rootOn = false)
        assertTrue(p.contains("গার্লফ্রেন্ড মোড"))
        assertTrue(p.contains("যৌন বা অশ্লীল কথা নয়"))
        assertTrue(p.contains("তুমি একজন AI"))
        assertTrue(p.contains("ডিফল্ট ভাষা বাংলা"))
    }

    @Test fun everyPersonalityHasAVoice() {
        Personality.entries.forEach { assertTrue(it.voice.isNotBlank()) }
    }

    @Test fun rootWarningWhenUnavailable() {
        val p = SystemPromptBuilder.build(Personality.ASSISTANT, accessibilityOn = false, rootOn = false)
        assertTrue(p.contains("Root ব্যবহারযোগ্য নয়"))
    }
}
