package com.anas.ai

import com.anas.ai.root.RootOperation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RootOperationTest {
    @Test fun forceStopValidPackage() {
        val op = RootOperation.parse("force_stop", mapOf("package" to "com.example.app"))
        assertNotNull(op)
        assertEquals("am force-stop com.example.app", op!!.command)
        assertTrue(op.requiresConfirmation)
    }

    @Test fun shellInjectionRejected() {
        assertNull(RootOperation.parse("force_stop", mapOf("package" to "com.a; rm -rf /")))
        assertNull(RootOperation.parse("force_stop", mapOf("package" to "com.a && reboot")))
        assertNull(RootOperation.parse("launch_app", mapOf("package" to "\$(id).x")))
    }

    @Test fun dangerousOperationsDoNotExist() {
        listOf("reboot", "shutdown", "factory_reset", "wipe", "shell", "rm", "pm_uninstall").forEach {
            assertNull(it, RootOperation.parse(it, mapOf("package" to "com.a.b")))
        }
    }

    @Test fun brightnessRange() {
        assertNotNull(RootOperation.parse("set_brightness", mapOf("level" to "128")))
        assertNull(RootOperation.parse("set_brightness", mapOf("level" to "300")))
        assertNull(RootOperation.parse("set_brightness", mapOf("level" to "1; id")))
    }

    @Test fun wifiConnectQuotesArguments() {
        val op = RootOperation.parse("wifi_connect", mapOf("ssid" to "a'; reboot; '", "security" to "wpa2", "password" to "password123"))
        assertNotNull(op)
        assertTrue(op!!.command.startsWith("cmd wifi connect-network 'a'\\''; reboot; '\\''' wpa2 'password123'"))
        assertTrue(op.requiresConfirmation)
        assertFalse(op.toString().contains("password123"))
    }

    @Test fun wifiConnectValidation() {
        assertNull(RootOperation.parse("wifi_connect", mapOf("ssid" to "Home", "security" to "wpa2", "password" to "short")))
        assertNull(RootOperation.parse("wifi_connect", mapOf("ssid" to "", "security" to "open")))
        assertNull(RootOperation.parse("wifi_connect", mapOf("ssid" to "Home", "security" to "wep", "password" to "password123")))
        assertEquals(
            "cmd wifi connect-network 'Cafe' open",
            RootOperation.parse("wifi_connect", mapOf("ssid" to "Cafe", "security" to "open"))!!.command,
        )
    }

    @Test fun togglesAndConfirmation() {
        assertEquals("svc wifi enable", RootOperation.parse("set_wifi", mapOf("enabled" to "true"))!!.command)
        assertFalse(RootOperation.parse("set_wifi", mapOf("enabled" to "true"))!!.requiresConfirmation)
        assertTrue(RootOperation.parse("set_wifi", mapOf("enabled" to "false"))!!.requiresConfirmation)
        assertTrue(RootOperation.parse("set_airplane", mapOf("enabled" to "true"))!!.requiresConfirmation)
        assertNull(RootOperation.parse("set_wifi", mapOf("enabled" to "maybe")))
    }

    @Test fun keyEventAllowlist() {
        assertEquals("input keyevent 66", RootOperation.parse("key_event", mapOf("key" to "enter"))!!.command)
        assertNull(RootOperation.parse("key_event", mapOf("key" to "POWER")))
    }

    @Test fun urlNormalizeAndValidate() {
        val u = RootOperation.normalizeUrl("https://www.youtube.com/results?search_query=হাফিজ রহমান")
        assertTrue(u.startsWith("https://www.youtube.com/results?search_query=%E0%A6"))
        assertFalse(u.contains(' '))
        assertNotNull(RootOperation.parse("open_url", mapOf("url" to u)))
        assertNull(RootOperation.parse("open_url", mapOf("url" to "file:///sdcard/x")))
        assertNull(RootOperation.parse("open_url", mapOf("url" to "https://a.com/x y")))
    }
}
