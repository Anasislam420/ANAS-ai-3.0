package com.anas.ai

import com.anas.ai.root.RootOperation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RootOperationTest {
    @Test fun validPackageAccepted() {
        val op = RootOperation.parse("force_stop", "com.example.app")
        assertNotNull(op)
        assertEquals("am force-stop com.example.app", op!!.command)
        assertTrue(op.requiresConfirmation)
    }

    @Test fun shellInjectionRejected() {
        assertNull(RootOperation.parse("force_stop", "com.a; rm -rf /"))
        assertNull(RootOperation.parse("force_stop", "com.a && reboot"))
        assertNull(RootOperation.parse("force_stop", "\$(id).x"))
    }

    @Test fun brightnessRange() {
        assertNotNull(RootOperation.parse("set_brightness", "128"))
        assertNull(RootOperation.parse("set_brightness", "300"))
        assertNull(RootOperation.parse("set_brightness", "-1"))
        assertNull(RootOperation.parse("set_brightness", "1; id"))
    }

    @Test fun unknownOperationRejected() {
        assertNull(RootOperation.parse("rm_rf", null))
        assertNull(RootOperation.parse("shell", "ls"))
    }

    @Test fun safeOperationsNeedNoConfirmation() {
        assertEquals(false, RootOperation.parse("battery_info", null)!!.requiresConfirmation)
        assertEquals(true, RootOperation.parse("reboot", null)!!.requiresConfirmation)
    }
}
