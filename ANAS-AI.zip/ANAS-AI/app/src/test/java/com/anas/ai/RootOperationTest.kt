package com.anas.ai

import com.anas.ai.root.RootOperation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RootOperationTest {
    @Test fun forceStopValidPackage() {
        val op = RootOperation.parse("force_stop", mapOf("package" to "com.example.app"))
        assertNotNull(op)
        assertEquals("am force-stop com.example.app", op!!.command)
        assertTrue(op.requiresConfirmation)
    }

    @Test fun shellInjectionRejected() {
        assertNull(RootOperation.parse("force_stop", mapOf("package" to "com.a; rm -rf /")))
        assertNull(RootOperation.parse("force_stop", mapOf("package" to "com.a && reboot")))
        assertNull(RootOperation.parse("launch_app", mapOf("package" to "\$(id).x")))
        assertNull(RootOperation.parse("custom_shell", mapOf("command" to "rm -rf /sdcard")))
    }

    @Test fun highLevelRootOperationsWork() {
        val callOp = RootOperation.parse("direct_call", mapOf("number" to "+8801712345678"))
        assertNotNull(callOp)
        assertTrue(callOp!!.command.contains("android.intent.action.CALL"))

        val tapOp = RootOperation.parse("root_tap", mapOf("x" to "540", "y" to "1200"))
        assertNotNull(tapOp)
        assertEquals("input tap 540 1200", tapOp!!.command)

        val shellOp = RootOperation.parse("custom_shell", mapOf("command" to "settings put global animator_duration_scale 0.5"))
        assertNotNull(shellOp)
    }

    @Test fun brightnessRange() {
        assertNotNull(RootOperation.parse("set_brightness", mapOf("level" to "128")))
        assertNull(RootOperation.parse("set_brightness", mapOf("level" to "300")))
        assertNull(RootOperation.parse("set_brightness", mapOf("level" to "1; id")))
    }

    @Test fun wifiConnectQuotesArguments() {
        val op = RootOperation.parse("wifi_connect", mapOf("ssid" to "a'; reboot; '", "security" to "wpa2", "password" to "password123"))
        assertNotNull(op)
        assertTrue(op!!.command.startsWith("cmd wifi connect-network 'a'\\''; reboot; '\\''' wpa2 'password123'"))
        assertTrue(op.requiresConfirmation)
        assertFalse(op.toString().contains("password123"))
    }

    @Test fun togglesAndConfirmation() {
        assertEquals("svc wifi enable", RootOperation.parse("set_wifi", mapOf("enabled" to "true"))!!.command)
        assertFalse(RootOperation.parse("set_wifi", mapOf("enabled" to "true"))!!.requiresConfirmation)
        assertTrue(RootOperation.parse("set_wifi", mapOf("enabled" to "false"))!!.requiresConfirmation)
        assertTrue(RootOperation.parse("set_airplane", mapOf("enabled" to "true"))!!.requiresConfirmation)
        assertNull(RootOperation.parse("set_wifi", mapOf("enabled" to "maybe")))
    }

    @Test fun keyEventAllowlist() {
        assertEquals("input keyevent 66", RootOperation.parse("key_event", mapOf("key" to "enter"))!!.command)
        assertEquals("input keyevent 5", RootOperation.parse("key_event", mapOf("key" to "CALL"))!!.command)
        assertNull(RootOperation.parse("key_event", mapOf("key" to "INVALID_KEY")))
    }

    @Test fun urlNormalizeAndValidate() {
        val u = RootOperation.normalizeUrl("https://www.youtube.com/results?search_query=হাফিজ রহমান")
        assertTrue(u.startsWith("https://www.youtube.com/results?search_query=%E0%A6"))
        assertFalse(u.contains(' '))
        assertNotNull(RootOperation.parse("open_url", mapOf("url" to u)))
        assertNull(RootOperation.parse("open_url", mapOf("url" to "file:///sdcard/x")))
        assertNull(RootOperation.parse("open_url", mapOf("url" to "https://a.com/x y")))
    }
}
