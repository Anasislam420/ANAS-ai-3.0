package com.anas.ai

import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.anas.ai.core.SecureKeyStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PackageInstrumentedTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext

    @Test fun packageName() = assertEquals("com.anas.ai", ctx.packageName)

    @Test fun apiKeyRoundTrip() {
        val s = SecureKeyStore(ctx)
        s.apiKey = "test-key-1234"
        assertEquals("test-key-1234", s.apiKey)
        s.apiKey = null
        assertNull(s.apiKey)
    }
}
