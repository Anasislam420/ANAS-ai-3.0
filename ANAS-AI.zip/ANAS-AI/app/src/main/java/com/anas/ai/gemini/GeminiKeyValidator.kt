package com.anas.ai.gemini

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

sealed interface KeyValidation {
    data object Valid : KeyValidation
    data object ValidModelMissing : KeyValidation
    data class Invalid(val message: String) : KeyValidation
    data class NetworkError(val message: String) : KeyValidation
}

/** Models list endpoint দিয়ে কী ও মডেলের উপস্থিতি যাচাই। কী header-এ যায়, URL বা লগে নয়। */
object GeminiKeyValidator {
    suspend fun validate(http: OkHttpClient, apiKey: String, model: String): KeyValidation =
        withContext(Dispatchers.IO) {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000")
                .header("x-goog-api-key", apiKey)
                .build()
            try {
                http.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    when {
                        resp.isSuccessful -> {
                            val names = JSONObject(body).optJSONArray("models")
                            val wanted = "models/$model"
                            val found = names != null && (0 until names.length()).any {
                                names.getJSONObject(it).optString("name") == wanted
                            }
                            if (found) KeyValidation.Valid else KeyValidation.ValidModelMissing
                        }
                        resp.code in 400..403 -> KeyValidation.Invalid("HTTP ${resp.code}")
                        else -> KeyValidation.NetworkError("HTTP ${resp.code}")
                    }
                }
            } catch (e: Exception) {
                KeyValidation.NetworkError(e.javaClass.simpleName)
            }
        }
}
