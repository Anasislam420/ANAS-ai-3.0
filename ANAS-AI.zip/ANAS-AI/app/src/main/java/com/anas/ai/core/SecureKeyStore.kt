package com.anas.ai.core

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API Key Android Keystore-সমর্থিত EncryptedSharedPreferences-এ থাকে। প্লেইন টেক্সটে কখনো নয়। */
class SecureKeyStore(context: Context) {

    private val secure: SharedPreferences? = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context, "anas_secure", masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        null
    }

    private val prefs: SharedPreferences = context.getSharedPreferences("anas_prefs", Context.MODE_PRIVATE)

    val isSecureAvailable: Boolean get() = secure != null

    var apiKey: String?
        get() = secure?.getString(KEY_API, null)?.takeIf { it.isNotBlank() }
        set(value) {
            val s = secure ?: return
            if (value.isNullOrBlank()) s.edit().remove(KEY_API).apply()
            else s.edit().putString(KEY_API, value.trim()).apply()
        }

    var model: String
        get() = prefs.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = prefs.edit().putString(KEY_MODEL, value.trim().ifBlank { DEFAULT_MODEL }).apply()

    var personality: Personality
        get() = Personality.fromKey(prefs.getString(KEY_PERSONALITY, null))
        set(value) = prefs.edit().putString(KEY_PERSONALITY, value.key).apply()

    var rootEnabled: Boolean
        get() = prefs.getBoolean(KEY_ROOT, true)
        set(value) = prefs.edit().putBoolean(KEY_ROOT, value).apply()

    var autoApproveRoot: Boolean
        get() = prefs.getBoolean(KEY_AUTO_ROOT, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_ROOT, value).apply()

    companion object {
        private const val KEY_API = "gemini_api_key"
        private const val KEY_MODEL = "model"
        private const val KEY_PERSONALITY = "personality"
        private const val KEY_ROOT = "root_enabled"
        private const val KEY_AUTO_ROOT = "auto_approve_root"

        /** সেটিংসে বদলানো যায়; ব্যবহারের আগে "যাচাই ও সংরক্ষণ" চালিয়ে তালিকায় আছে কি না দেখে নিন। */
        const val DEFAULT_MODEL = "gemini-2.5-flash-native-audio-preview-12-2025"

        /** UI বা লগে সম্পূর্ণ কী দেখানো হয় না। */
        fun mask(key: String?): String =
            if (key.isNullOrBlank()) "" else "••••••••" + key.takeLast(4)
    }
}
