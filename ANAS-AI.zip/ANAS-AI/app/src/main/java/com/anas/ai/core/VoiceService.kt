package com.anas.ai.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.anas.ai.AnasApp
import com.anas.ai.R
import com.anas.ai.ui.MainActivity

/** সেশন চলাকালীন মাইক্রোফোন ফোরগ্রাউন্ড সার্ভিস, যাতে অন্য অ্যাপে কাজ করার সময়ও সেশন চলে। */
class VoiceService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            (application as AnasApp).engine.stopSession()
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel(this)
        val n = buildNotification(this, getString(R.string.notif_text))
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(NOTIF_ID, n)
        return START_NOT_STICKY
    }

    companion object {
        private const val CHANNEL = "voice_session"
        private const val NOTIF_ID = 42
        private const val ACTION_STOP = "com.anas.ai.STOP"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, VoiceService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, VoiceService::class.java))
        }

        fun notifyConfirmation(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            try {
                nm.notify(NOTIF_ID, buildNotification(ctx, "নিশ্চিতকরণ প্রয়োজন — অ্যাপ খুলে অনুমতি দিন"))
            } catch (_: Exception) {}
        }

        private fun createChannel(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, ctx.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW),
            )
        }

        private fun buildNotification(ctx: Context, text: String): Notification {
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val stop = PendingIntent.getService(
                ctx, 1, Intent(ctx, VoiceService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            return NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_orb)
                .setContentTitle(ctx.getString(R.string.notif_title))
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(0, ctx.getString(R.string.notif_stop), stop)
                .build()
        }
    }
}
