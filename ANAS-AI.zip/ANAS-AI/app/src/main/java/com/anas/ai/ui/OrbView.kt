package com.anas.ai.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.ColorUtils
import com.anas.ai.core.AssistantState
import kotlin.math.min
import kotlin.math.sin

/** বাইরের JavaScript ছাড়া নিজস্ব reactive Orb: অবস্থা অনুযায়ী রং, অডিও স্তর অনুযায়ী স্পন্দন। */
class OrbView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0,
) : View(context, attrs, defStyle) {

    var state: AssistantState = AssistantState.OFFLINE
    var level: Float = 0f

    private var smooth = 0f
    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density

    private fun colorFor(s: AssistantState) = when (s) {
        AssistantState.OFFLINE -> 0xFF64748B.toInt()
        AssistantState.CONNECTING -> 0xFFFBBF24.toInt()
        AssistantState.LISTENING -> 0xFF22D3EE.toInt()
        AssistantState.THINKING -> 0xFFA78BFA.toInt()
        AssistantState.SPEAKING -> 0xFFF472B6.toInt()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        smooth += (level - smooth) * 0.25f
        phase += when (state) {
            AssistantState.THINKING -> 0.10f
            AssistantState.CONNECTING -> 0.14f
            else -> 0.04f
        }
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) * 0.26f
        val amp = when (state) {
            AssistantState.LISTENING, AssistantState.SPEAKING -> smooth * 0.45f
            AssistantState.THINKING -> 0.08f * sin(phase * 2f)
            else -> 0f
        }
        val r = base * (1f + 0.04f * sin(phase) + amp)
        val color = colorFor(state)

        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, r * 1.9f,
            intArrayOf(ColorUtils.setAlphaComponent(color, 110), ColorUtils.setAlphaComponent(color, 0)),
            null, Shader.TileMode.CLAMP,
        )
        canvas.drawCircle(cx, cy, r * 1.9f, paint)

        paint.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.3f, r * 1.3f,
            intArrayOf(ColorUtils.blendARGB(color, Color.WHITE, 0.5f), color, ColorUtils.blendARGB(color, Color.BLACK, 0.55f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP,
        )
        canvas.drawCircle(cx, cy, r, paint)

        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * density
        paint.color = ColorUtils.setAlphaComponent(color, 90)
        canvas.drawCircle(cx, cy, r * 1.25f + 5f * density * sin(phase * 1.5f), paint)
        paint.color = ColorUtils.setAlphaComponent(color, 45)
        canvas.drawCircle(cx, cy, r * 1.5f + 7f * density * sin(phase * 1.1f + 1f), paint)

        postInvalidateOnAnimation()
    }
}
