package com.anas.ai.automation

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

object AutomationCapabilityChecker {

    /** সিস্টেম সেটিংসে সার্ভিসটি চালু করা আছে কি না। */
    fun isAccessibilityEnabled(context: Context): Boolean {
        val setting = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        val mine = ComponentName(context, JarvisAccessibilityService::class.java)
        return setting.split(':').any { ComponentName.unflattenFromString(it) == mine }
    }

    /** চালু থাকা এবং সিস্টেমের সঙ্গে সংযুক্ত (instance আছে)। */
    fun isAccessibilityConnected(): Boolean = JarvisAccessibilityService.instance != null
}
