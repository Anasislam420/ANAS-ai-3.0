package com.anas.ai.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.anas.ai.R
import com.anas.ai.core.ChatMessage
import com.anas.ai.core.Role
import com.anas.ai.databinding.ItemMessageBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter : ListAdapter<ChatMessage, MessageAdapter.VH>(Diff) {

    private val fmt = SimpleDateFormat("hh:mm a", Locale("bn", "BD"))

    class VH(val b: ItemMessageBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = getItem(position)
        val ctx = holder.b.root.context
        holder.b.tvRole.text = ctx.getString(
            when (m.role) {
                Role.USER -> R.string.role_user
                Role.AI -> R.string.role_ai
                Role.SYSTEM -> R.string.role_system
            },
        )
        holder.b.tvText.text = m.text
        holder.b.tvTime.text = fmt.format(Date(m.timestamp))
    }

    private object Diff : DiffUtil.ItemCallback<ChatMessage>() {
        override fun areItemsTheSame(a: ChatMessage, b: ChatMessage) = a.id == b.id
        override fun areContentsTheSame(a: ChatMessage, b: ChatMessage) = a == b
    }
}
