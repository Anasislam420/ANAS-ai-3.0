package com.anas.ai.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** মাইক্রোফোন → 16 kHz, mono, PCM 16-bit little-endian (Gemini Live ইনপুটের ফরম্যাট)। */
class AudioRecorder {
    private var record: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var job: Job? = null

    @SuppressLint("MissingPermission")
    fun start(scope: CoroutineScope, onChunk: (ByteArray, Float) -> Unit): Boolean {
        if (job?.isActive == true) return true
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return false
        val chunkBytes = RATE / 1000 * 40 * 2 // ৪০ মি.সে.
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                max(minBuf, chunkBytes * 4),
            )
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(rec.audioSessionId)?.also { it.enabled = true }
        record = rec
        rec.startRecording()
        job = scope.launch(Dispatchers.IO) {
            val buf = ByteArray(chunkBytes)
            while (isActive) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    val data = buf.copyOf(n)
                    onChunk(data, level(data))
                } else if (n < 0) break
            }
        }
        return true
    }

    fun stop() {
        job?.cancel()
        job = null
        record?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        record = null
        aec?.release(); aec = null
        ns?.release(); ns = null
    }

    companion object {
        const val RATE = 16_000

        /** 0..1 স্তর (Orb-এর জন্য)। */
        fun level(pcm: ByteArray): Float {
            val samples = pcm.size / 2
            if (samples == 0) return 0f
            var sum = 0.0
            for (i in 0 until samples) {
                val v = ((pcm[2 * i + 1].toInt() shl 8) or (pcm[2 * i].toInt() and 0xFF)).toShort().toInt()
                sum += v.toDouble() * v
            }
            val rms = sqrt(sum / samples) / 32768.0
            return min(1f, (rms * 5.0).toFloat())
        }
    }
}
