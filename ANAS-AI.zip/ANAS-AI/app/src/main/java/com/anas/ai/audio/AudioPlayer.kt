package com.anas.ai.audio

import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max

/** Gemini Live আউটপুট: 24 kHz, mono, PCM 16-bit। flush() দিয়ে barge-in-এ সঙ্গে সঙ্গে থামানো যায়। */
class AudioPlayer(private val onLevel: (Float) -> Unit) {
    private var track: AudioTrack? = null
    private var queue = Channel<ByteArray>(Channel.UNLIMITED)
    private var job: Job? = null
    private val pendingBytes = AtomicLong(0)
    private val lock = Any()

    /** [preferred] দিলে (যেমন বিল্ট-ইন স্পিকার) আউটপুট জোর করে সেদিকে যায়, ইয়ারপিসে নয়। */
    fun start(scope: CoroutineScope, preferred: AudioDeviceInfo? = null) {
        synchronized(lock) {
            if (job?.isActive == true) return
            val minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
                )
                .setBufferSizeInBytes(max(minBuf, RATE))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            t.setVolume(1.0f)
            preferred?.let { t.setPreferredDevice(it) }
            t.play()
            track = t
            queue = Channel(Channel.UNLIMITED)
            val q = queue
            job = scope.launch(Dispatchers.IO) {
                for (chunk in q) {
                    onLevel(AudioRecorder.level(chunk))
                    t.write(chunk, 0, chunk.size)
                    pendingBytes.addAndGet(-chunk.size.toLong())
                }
            }
        }
    }

    fun enqueue(pcm: ByteArray) {
        pendingBytes.addAndGet(pcm.size.toLong())
        queue.trySend(pcm)
    }

    /** কিউয়ে বাকি অডিওর আনুমানিক সময় (মি.সে.)। 24000 Hz × 2 বাইট = 48 বাইট/মি.সে.। */
    fun pendingMs(): Long = max(0, pendingBytes.get()) / 48

    /** চলমান ও অপেক্ষমাণ সব অডিও বাতিল। */
    fun flush() {
        synchronized(lock) {
            while (queue.tryReceive().isSuccess) { /* drain */ }
            pendingBytes.set(0)
            track?.let {
                try {
                    it.pause()
                    it.flush()
                    it.play()
                } catch (_: Exception) {}
            }
        }
        onLevel(0f)
    }

    fun stop() {
        synchronized(lock) {
            job?.cancel(); job = null
            queue.close()
            track?.let {
                try { it.stop() } catch (_: Exception) {}
                it.release()
            }
            track = null
            pendingBytes.set(0)
        }
    }

    companion object { const val RATE = 24_000 }
}
