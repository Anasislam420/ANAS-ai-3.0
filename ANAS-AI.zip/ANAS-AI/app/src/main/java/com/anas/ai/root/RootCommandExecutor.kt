package com.anas.ai.root

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

data class RootResult(val ok: Boolean, val exitCode: Int, val output: String, val error: String)

/** শুধু যাচাইকৃত [RootOperation] চালায়; কাঁচা স্ট্রিং গ্রহণ করে না। */
class RootCommandExecutor {
    suspend fun run(op: RootOperation): RootResult = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder("su", "-c", op.command).start()
            coroutineScope {
                val out = async { p.inputStream.bufferedReader().readText() }
                val err = async { p.errorStream.bufferedReader().readText() }
                if (!p.waitFor(15, TimeUnit.SECONDS)) {
                    p.destroyForcibly()
                    return@coroutineScope RootResult(false, -1, "", "সময় শেষ (timeout)")
                }
                val code = p.exitValue()
                RootResult(code == 0, code, out.await().take(1500), err.await().take(500))
            }
        } catch (e: Exception) {
            RootResult(false, -1, "", e.javaClass.simpleName)
        }
    }
}
