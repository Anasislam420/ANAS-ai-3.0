package com.anas.ai.root

import android.os.Build
import com.anas.ai.core.RootStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/** ডিভাইসে su আছে কি না এবং অনুমতি মিলেছে কি না যাচাই করে। মূল ভয়েস ফিচার এর ওপর নির্ভর করে না। */
class RootCapabilityChecker {

    data class Report(
        val status: RootStatus,
        val sdk: Int = Build.VERSION.SDK_INT,
        val selinux: String = "unknown",
        val note: String = "",
    )

    @Volatile var lastReport: Report = Report(RootStatus.UNKNOWN)
        private set

    val status: RootStatus get() = lastReport.status

    /** su বাইনারি আছে কি না, এবং `su -c id` uid=0 দেয় কি না (Superuser অ্যাপ এখানে অনুমতি চাইতে পারে)। */
    suspend fun check(): Report = withContext(Dispatchers.IO) {
        val selinux = runPlain("getenforce")
        val suPresent = SU_PATHS.any { File(it).exists() }
        val report = if (!suPresent) {
            Report(RootStatus.NOT_AVAILABLE, selinux = selinux, note = "su পাওয়া যায়নি")
        } else {
            try {
                val p = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
                if (!p.waitFor(15, TimeUnit.SECONDS)) {
                    p.destroyForcibly()
                    Report(RootStatus.DENIED, selinux = selinux, note = "অনুমতির জন্য সময় শেষ")
                } else {
                    val out = p.inputStream.bufferedReader().readText()
                    if (p.exitValue() == 0 && out.contains("uid=0")) Report(RootStatus.GRANTED, selinux = selinux)
                    else Report(RootStatus.DENIED, selinux = selinux, note = "অনুমতি প্রত্যাখ্যাত")
                }
            } catch (e: Exception) {
                Report(RootStatus.NOT_AVAILABLE, selinux = selinux, note = e.javaClass.simpleName)
            }
        }
        lastReport = report
        report
    }

    private fun runPlain(cmd: String): String = try {
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        p.waitFor(3, TimeUnit.SECONDS)
        p.inputStream.bufferedReader().readText().trim().ifBlank { "unknown" }
    } catch (e: Exception) {
        "unknown"
    }

    private companion object {
        val SU_PATHS = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
            "/system/sbin/su", "/vendor/bin/su", "/data/adb/magisk/su", "/debug_ramdisk/su",
        )
    }
}
