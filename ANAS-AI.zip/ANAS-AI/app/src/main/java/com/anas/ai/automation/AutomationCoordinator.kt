package com.anas.ai.automation

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import com.anas.ai.R
import com.anas.ai.core.RootStatus
import com.anas.ai.core.SecureKeyStore
import com.anas.ai.root.RootCapabilityChecker
import com.anas.ai.root.RootCommandExecutor
import com.anas.ai.root.RootOperation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * AI-এর টুল কল গ্রহণ করে Accessibility বা (অনুমতি থাকলে) Root মডিউলে পাঠায়, এবং প্রতিটির ফলাফল যাচাই করে ফেরত দেয়।
 * [paused] true হলে সব কাজ প্রত্যাখ্যাত — এটিই Stop/Cancel নিয়ন্ত্রণ।
 */
class AutomationCoordinator(
    private val context: Context,
    private val rootChecker: RootCapabilityChecker,
    private val rootExecutor: RootCommandExecutor,
    private val store: SecureKeyStore,
    private val confirm: suspend (String) -> Boolean,
) {
    private val _paused = MutableStateFlow(false)
    val paused: StateFlow<Boolean> = _paused.asStateFlow()

    fun setPaused(value: Boolean) { _paused.value = value }

    private fun ok(vararg kv: Pair<String, Any?>) = JSONObject().put("ok", true).also { o -> kv.forEach { o.put(it.first, it.second) } }
    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)

    suspend fun execute(name: String, args: JSONObject): JSONObject {
        if (_paused.value) return fail("ব্যবহারকারী অটোমেশন বন্ধ রেখেছেন।")
        if (name == "root_action") return rootAction(args)

        val svc = JarvisAccessibilityService.instance
            ?: return fail(context.getString(R.string.a11y_not_enabled))

        return when (name) {
            "get_screen" -> {
                val nodes = svc.snapshot()
                if (nodes.isEmpty()) fail("স্ক্রিনের কিছু পড়া যায়নি (অ্যাপটি সুরক্ষিত হতে পারে)।")
                else {
                    val arr = JSONArray()
                    nodes.forEach {
                        arr.put(
                            JSONObject().put("text", it.text).put("desc", it.desc).put("id", it.id).put("type", it.cls)
                                .put("clickable", it.clickable).put("editable", it.editable).put("scrollable", it.scrollable),
                        )
                    }
                    ok("nodes" to arr, "count" to nodes.size)
                }
            }
            "tap_text", "long_press_text" -> {
                val label = args.optString("text")
                if (label.isBlank()) return fail("text দেওয়া হয়নি।")
                verified(svc) { svc.tapByText(label, longPress = name == "long_press_text") }
            }
            "scroll" -> {
                val forward = args.optString("direction").lowercase() != "up"
                verified(svc) { svc.scroll(forward) }
            }
            "type_text" -> {
                val t = args.optString("text")
                if (t.isEmpty()) return fail("text দেওয়া হয়নি।")
                verified(svc) { svc.typeText(t) }
            }
            "press_system" -> {
                val action = when (args.optString("button").lowercase()) {
                    "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                    "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                    "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                    "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                    else -> return fail("অজানা বোতাম।")
                }
                verified(svc) { svc.global(action) }
            }
            "open_app" -> openApp(svc, args.optString("name"))
            else -> fail("অজানা টুল: $name")
        }
    }

    /** কাজ চালিয়ে স্ক্রিনের স্বাক্ষর আগে-পরে মিলিয়ে ফলাফল জানায়। */
    private suspend fun verified(svc: JarvisAccessibilityService, action: () -> Boolean): JSONObject {
        val before = svc.signature()
        val performed = action()
        if (!performed) return fail("কাজটি করা যায়নি (এলিমেন্ট পাওয়া যায়নি বা Android অনুমতি দেয়নি)।")
        delay(700)
        val changed = svc.signature() != before
        return ok("screen_changed" to changed)
    }

    private suspend fun openApp(svc: JarvisAccessibilityService, query: String): JSONObject {
        if (query.isBlank()) return fail("অ্যাপের নাম দেওয়া হয়নি।")
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0)
            .map { it to it.loadLabel(pm).toString() }
            .let { list -> list.firstOrNull { it.second.equals(query, true) } ?: list.firstOrNull { it.second.contains(query, true) } }
            ?: return fail("\"$query\" নামের অ্যাপ পাওয়া যায়নি।")
        val intent = pm.getLaunchIntentForPackage(match.first.activityInfo.packageName)
            ?: return fail("অ্যাপটি খোলা যায়নি।")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            val before = svc.signature()
            svc.startActivity(intent)
            delay(1200)
            ok("opened" to match.second, "screen_changed" to (svc.signature() != before))
        } catch (e: Exception) {
            fail("Android ব্যাকগ্রাউন্ড থেকে অ্যাপ খুলতে দেয়নি।")
        }
    }

    private suspend fun rootAction(args: JSONObject): JSONObject {
        if (!store.rootEnabled) return fail("সেটিংসে Root ব্যবহার বন্ধ আছে। Accessibility দিয়ে চেষ্টা করুন।")
        val report = rootChecker.check()
        if (report.status != RootStatus.GRANTED) return fail("Root পাওয়া যায়নি বা অনুমতি নেই। Accessibility দিয়ে চেষ্টা করুন।")
        val op = RootOperation.parse(args.optString("operation"), args.optString("argument").ifBlank { null })
            ?: return fail("অনুমোদিত নয় এমন অপারেশন বা অবৈধ আর্গুমেন্ট।")
        if (op.requiresConfirmation && !confirm("Root দিয়ে: ${op.describeBn()}। অনুমতি দেবেন?")) {
            return fail("ব্যবহারকারী অনুমতি দেননি।")
        }
        val r = rootExecutor.run(op)
        return JSONObject().put("ok", r.ok).put("exit_code", r.exitCode).put("output", r.output).apply {
            if (!r.ok) put("error", r.error)
        }
    }
}
