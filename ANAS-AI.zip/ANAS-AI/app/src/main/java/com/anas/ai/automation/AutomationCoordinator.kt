package com.anas.ai.automation

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import com.anas.ai.R
import com.anas.ai.core.RootStatus
import com.anas.ai.core.SecureKeyStore
import com.anas.ai.root.RootCapabilityChecker
import com.anas.ai.root.RootCommandExecutor
import com.anas.ai.root.RootOperation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * AI-এর টুল কল গ্রহণ করে Accessibility বা (অনুমতি থাকলে) Root মডিউলে পাঠায় এবং প্রতিটির ফলাফল যাচাই করে ফেরত দেয়।
 * [paused] true হলে সব কাজ প্রত্যাখ্যাত — এটিই Stop/Cancel নিয়ন্ত্রণ।
 */
class AutomationCoordinator(
    private val context: Context,
    private val rootChecker: RootCapabilityChecker,
    private val rootExecutor: RootCommandExecutor,
    private val store: SecureKeyStore,
    private val confirm: suspend (String) -> Boolean,
) {
    private val _paused = MutableStateFlow(false)
    val paused: StateFlow<Boolean> = _paused.asStateFlow()

    /** ভাসমান ম্যাস্কটে দেখানো বর্তমান কাজের বিবরণ। */
    private val _label = MutableStateFlow<String?>(null)
    val actionLabel: StateFlow<String?> = _label.asStateFlow()

    fun setPaused(value: Boolean) {
        _paused.value = value
        if (value) _label.value = null
    }

    private fun ok(vararg kv: Pair<String, Any?>) = JSONObject().put("ok", true).also { o -> kv.forEach { o.put(it.first, it.second) } }
    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)

    suspend fun execute(name: String, args: JSONObject): JSONObject {
        if (_paused.value) return fail("ব্যবহারকারী অটোমেশন বন্ধ রেখেছেন।")
        _label.value = LABELS[name] ?: "কাজ করছি…"
        try {
            return dispatch(name, args)
        } finally {
            _label.value = null
        }
    }

    private suspend fun dispatch(name: String, args: JSONObject): JSONObject = when (name) {
        "wait" -> {
            delay((args.optDouble("seconds", 1.0).coerceIn(0.5, 5.0) * 1000).toLong())
            ok()
        }
        "set_volume" -> setVolume(args.optInt("level", -1))
        "open_url" -> openUrl(args.optString("url"))
        "open_app" -> openApp(args.optString("name"))
        in ToolDispatcher.ROOT_TOOLS -> rootTool(name, args)
        else -> accessibilityTool(name, args)
    }

    // ---------- Accessibility ----------

    private suspend fun accessibilityTool(name: String, args: JSONObject): JSONObject {
        val svc = JarvisAccessibilityService.instance ?: return fail(context.getString(R.string.a11y_not_enabled))
        return when (name) {
            "get_screen" -> {
                val nodes = svc.snapshot()
                if (nodes.isEmpty()) fail("স্ক্রিনের কিছু পড়া যায়নি (অ্যাপটি সুরক্ষিত হতে পারে)।")
                else {
                    val arr = JSONArray()
                    nodes.forEach {
                        val o = JSONObject().put("text", it.text).put("desc", it.desc).put("type", it.cls)
                            .put("clickable", it.clickable).put("editable", it.editable).put("scrollable", it.scrollable)
                        val b = it.bounds.split(',').mapNotNull { s -> s.toIntOrNull() }
                        if (b.size == 4) o.put("center", JSONArray().put((b[0] + b[2]) / 2).put((b[1] + b[3]) / 2))
                        arr.put(o)
                    }
                    ok("nodes" to arr, "count" to nodes.size)
                }
            }
            "tap_text", "long_press_text" -> {
                val label = args.optString("text")
                if (label.isBlank()) return fail("text দেওয়া হয়নি।")
                verified(svc) { svc.tapByText(label, longPress = name == "long_press_text") }
            }
            "tap_xy" -> {
                val x = args.optInt("x", -1)
                val y = args.optInt("y", -1)
                if (x < 0 || y < 0) return fail("x ও y দিন।")
                verified(svc) { svc.tapAt(x, y) }
            }
            "scroll" -> {
                val forward = args.optString("direction").lowercase() != "up"
                verified(svc) { svc.scroll(forward) }
            }
            "swipe" -> verified(svc) { svc.swipe(args.optString("direction").lowercase()) }
            "type_text" -> typeText(svc, args)
            "press_system" -> {
                val action = when (args.optString("button").lowercase()) {
                    "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                    "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                    "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                    "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                    else -> return fail("অজানা বোতাম।")
                }
                verified(svc) { svc.global(action) }
            }
            else -> fail("অজানা টুল: $name")
        }
    }

    /** কাজ চালিয়ে স্ক্রিনের স্বাক্ষর আগে-পরে মিলিয়ে ফলাফল জানায়। */
    private suspend fun verified(svc: JarvisAccessibilityService, action: suspend () -> Boolean): JSONObject {
        val before = svc.signature()
        if (!action()) return fail("কাজটি করা যায়নি (এলিমেন্ট পাওয়া যায়নি বা Android অনুমতি দেয়নি)।")
        delay(700)
        return ok("screen_changed" to (svc.signature() != before))
    }

    private suspend fun typeText(svc: JarvisAccessibilityService, args: JSONObject): JSONObject {
        val text = args.optString("text")
        if (text.isEmpty()) return fail("text দেওয়া হয়নি।")
        val submit = args.optBoolean("submit", false)
        val before = svc.signature()
        var allowPassword = false
        var result = JarvisAccessibilityService.TypeResult.NO_FIELD
        for (attempt in 0 until 6) { // ঘর দেখা দিতে একটু সময় লাগতে পারে
            result = svc.typeText(text, allowPassword)
            if (result == JarvisAccessibilityService.TypeResult.PASSWORD_BLOCKED) {
                if (!confirm("একটি পাসওয়ার্ড ঘরে লেখা হবে। অনুমতি দেবেন?")) return fail("ব্যবহারকারী অনুমতি দেননি।")
                allowPassword = true
                result = svc.typeText(text, true)
            }
            if (result != JarvisAccessibilityService.TypeResult.NO_FIELD) break
            delay(400)
        }
        when (result) {
            JarvisAccessibilityService.TypeResult.OK -> {}
            JarvisAccessibilityService.TypeResult.NO_FIELD -> return fail("কোনো লেখার ঘর পাওয়া যায়নি। আগে ঘরটিতে ট্যাপ করুন।")
            else -> return fail("লেখা যায়নি।")
        }
        var submitted = false
        if (submit) {
            delay(300)
            submitted = svc.imeEnter()
            if (!submitted && rootReady()) {
                RootOperation.parse("key_event", mapOf("key" to "ENTER"))?.let { submitted = rootExecutor.run(it).ok }
            }
        }
        delay(700)
        return ok("typed" to true, "submitted" to submitted, "screen_changed" to (svc.signature() != before))
    }

    // ---------- অ্যাপ/লিংক ----------

    private suspend fun rootReady(): Boolean =
        store.rootEnabled && (rootChecker.status == RootStatus.GRANTED || rootChecker.check().status == RootStatus.GRANTED)

    private suspend fun openUrl(raw: String): JSONObject {
        val url = RootOperation.normalizeUrl(raw)
        if (!(url.startsWith("https://") || url.startsWith("http://"))) return fail("শুধু http/https লিংক খোলা যায়।")
        val svc = JarvisAccessibilityService.instance
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val before = svc?.signature()
        var started = try { (svc ?: context).startActivity(intent); true } catch (e: Exception) { false }
        delay(1800)
        var changed = svc?.let { it.signature() != before } ?: started
        if ((!started || !changed) && rootReady()) {
            RootOperation.parse("open_url", mapOf("url" to url))?.let { started = rootExecutor.run(it).ok }
            delay(1800)
            changed = svc?.let { it.signature() != before } ?: started
        }
        return if (started) ok("opened" to url, "screen_changed" to changed) else fail("লিংক খোলা যায়নি।")
    }

    private suspend fun openApp(query: String): JSONObject {
        if (query.isBlank()) return fail("অ্যাপের নাম দেওয়া হয়নি।")
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0)
            .map { it to it.loadLabel(pm).toString() }
            .let { list -> list.firstOrNull { it.second.equals(query, true) } ?: list.firstOrNull { it.second.contains(query, true) } }
            ?: return fail("\"$query\" নামের অ্যাপ পাওয়া যায়নি।")
        val pkg = match.first.activityInfo.packageName
        val intent = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return fail("অ্যাপটি খোলা যায়নি।")
        val svc = JarvisAccessibilityService.instance
        val before = svc?.signature()
        var started = try { (svc ?: context).startActivity(intent); true } catch (e: Exception) { false }
        delay(1500)
        var changed = svc?.let { it.signature() != before } ?: started
        if ((!started || !changed) && rootReady()) {
            RootOperation.parse("launch_app", mapOf("package" to pkg))?.let { started = rootExecutor.run(it).ok }
            delay(1500)
            changed = svc?.let { it.signature() != before } ?: started
        }
        return if (started) ok("opened" to match.second, "screen_changed" to changed) else fail("Android অ্যাপ খুলতে দেয়নি।")
    }

    private fun setVolume(percent: Int): JSONObject {
        if (percent !in 0..100) return fail("০ থেকে ১০০ এর মধ্যে দিন।")
        return try {
            val am = context.getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (percent * max / 100.0).roundToInt(), 0)
            ok("percent" to percent)
        } catch (e: Exception) {
            fail("ভলিউম বদলানো যায়নি।")
        }
    }

    // ---------- Root ----------

    private suspend fun rootTool(name: String, args: JSONObject): JSONObject {
        if (!store.rootEnabled) return fail("সেটিংসে Root ব্যবহার বন্ধ আছে। Accessibility দিয়ে চেষ্টা করুন।")
        if (!rootReady()) return fail("Root পাওয়া যায়নি বা অনুমতি নেই। Accessibility দিয়ে চেষ্টা করুন।")
        val (op, map) = when (name) {
            "wifi_connect" -> "wifi_connect" to mapOf(
                "ssid" to args.optString("ssid"),
                "security" to args.optString("security", "wpa2"),
                "password" to args.optString("password"),
            )
            "set_toggle" -> ("set_" + args.optString("name")) to mapOf("enabled" to args.optBoolean("enabled").toString())
            "set_brightness" -> "set_brightness" to mapOf("level" to args.optInt("level", -1).toString())
            "key_event" -> "key_event" to mapOf("key" to args.optString("key"))
            "force_stop_app" -> "force_stop" to mapOf("package" to args.optString("package"))
            else -> (if (args.optString("kind") == "apps") "list_user_apps" else "battery_info") to emptyMap<String, String>()
        }
        val parsed = RootOperation.parse(op, map) ?: return fail("অনুমোদিত নয় এমন অপারেশন বা অবৈধ আর্গুমেন্ট।")
        if (parsed.requiresConfirmation && !confirm("Root দিয়ে: ${parsed.describeBn()}। অনুমতি দেবেন?")) {
            return fail("ব্যবহারকারী অনুমতি দেননি।")
        }
        val r = rootExecutor.run(parsed)
        return JSONObject().put("ok", r.ok).put("exit_code", r.exitCode).put("output", r.output).apply {
            if (!r.ok) put("error", r.error)
        }
    }

    private companion object {
        val LABELS = mapOf(
            "get_screen" to "স্ক্রিন দেখছি…",
            "tap_text" to "ট্যাপ করছি…", "long_press_text" to "ট্যাপ করছি…", "tap_xy" to "ট্যাপ করছি…",
            "scroll" to "স্ক্রল করছি…", "swipe" to "সোয়াইপ করছি…",
            "type_text" to "লিখছি…", "press_system" to "বোতাম চাপছি…",
            "open_app" to "অ্যাপ খুলছি…", "open_url" to "লিংক খুলছি…", "wait" to "অপেক্ষা করছি…",
            "set_volume" to "ভলিউম বদলাচ্ছি…",
            "wifi_connect" to "Wi-Fi সংযোগ করছি…", "set_toggle" to "সেটিংস বদলাচ্ছি…",
            "set_brightness" to "উজ্জ্বলতা বদলাচ্ছি…", "key_event" to "বোতাম চাপছি…",
            "force_stop_app" to "অ্যাপ বন্ধ করছি…", "root_info" to "তথ্য পড়ছি…",
        )
    }
}
