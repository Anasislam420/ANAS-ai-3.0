package com.anas.ai.automation

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.anas.ai.R
import com.anas.ai.core.RootStatus
import com.anas.ai.core.SecureKeyStore
import com.anas.ai.root.RootCapabilityChecker
import com.anas.ai.root.RootCommandExecutor
import com.anas.ai.root.RootOperation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * AI-এর টুল কল গ্রহণ করে ডিফল্ট ফোন কল, মিউজিক প্লেয়ার, ট্যাব কন্ট্রোল, Accessibility ও হাই-লেভেল Root মডিউলে পাঠায়।
 */
class AutomationCoordinator(
    private val context: Context,
    private val rootChecker: RootCapabilityChecker,
    private val rootExecutor: RootCommandExecutor,
    private val store: SecureKeyStore,
    private val confirm: suspend (String) -> Boolean,
) {
    private val _paused = MutableStateFlow(false)
    val paused: StateFlow<Boolean> = _paused.asStateFlow()

    /** ভাসমান ম্যাস্কটে দেখানো বর্তমান কাজের বিবরণ। */
    private val _label = MutableStateFlow<String?>(null)
    val actionLabel: StateFlow<String?> = _label.asStateFlow()

    fun setPaused(value: Boolean) {
        _paused.value = value
        if (value) _label.value = null
    }

    private fun ok(vararg kv: Pair<String, Any?>) = JSONObject().put("ok", true).also { o -> kv.forEach { o.put(it.first, it.second) } }
    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)

    suspend fun execute(name: String, args: JSONObject): JSONObject {
        if (_paused.value) return fail("ব্যবহারকারী অটোমেশন বন্ধ রেখেছেন।")
        _label.value = LABELS[name] ?: "কাজ করছি…"
        try {
            return dispatch(name, args)
        } finally {
            _label.value = null
        }
    }

    private suspend fun dispatch(name: String, args: JSONObject): JSONObject = when (name) {
        "wait" -> {
            delay((args.optDouble("seconds", 1.0).coerceIn(0.5, 5.0) * 1000).toLong())
            ok()
        }
        "call_phone" -> callPhone(args)
        "play_song" -> playSong(args)
        "control_tab" -> controlTab(args)
        "set_volume" -> setVolume(args.optInt("level", -1))
        "open_url" -> openUrl(args.optString("url"))
        "open_app" -> openApp(args.optString("name"))
        in ToolDispatcher.ROOT_TOOLS -> rootTool(name, args)
        else -> accessibilityTool(name, args)
    }

    // ---------- ডিফল্ট ও ডিরেক্ট ফোন কল ----------

    private suspend fun callPhone(args: JSONObject): JSONObject {
        val contactName = args.optString("name").trim()
        var number = args.optString("number").trim()
        var resolvedName = contactName

        if (number.isEmpty() && contactName.isNotEmpty()) {
            val found = findContactNumber(contactName)
            if (found != null) {
                resolvedName = found.first
                number = found.second
            } else {
                return fail("\"$contactName\" নামে কোনো কন্টাক্ট নাম্বার পাওয়া যায়নি (Contacts অনুমতি দেওয়া আছে কি না দেখুন বা সরাসরি নাম্বার বলুন)।")
            }
        }

        val cleanNum = number.replace(Regex("[\\s()-]"), "")
        if (cleanNum.length < 3) return fail("সঠিক ফোন নাম্বার বা কন্টাক্টের নাম দিন।")

        val hasCallPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val svc = JarvisAccessibilityService.instance

        // ১. CALL_PHONE অনুমতি থাকলে সরাসরি ডিফল্ট কল
        if (hasCallPerm) {
            try {
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$cleanNum")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                (svc ?: context).startActivity(intent)
                delay(1000)
                return ok("called" to cleanNum, "contact" to resolvedName, "method" to "direct_call")
            } catch (_: Exception) {}
        }

        // ২. Root থাকলে su দিয়ে সরাসরি কল (কোনো ডায়ালার অপেক্ষা ছাড়াই)
        if (rootReady()) {
            val op = RootOperation.parse("direct_call", mapOf("number" to cleanNum))
            if (op != null && rootExecutor.run(op).ok) {
                delay(1000)
                return ok("called" to cleanNum, "contact" to resolvedName, "method" to "root_direct_call")
            }
        }

        // ৩. ফলব্যাক: ডায়ালার খুলে অটো-কল ট্যাপ
        return try {
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanNum")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            (svc ?: context).startActivity(dialIntent)
            delay(1200)
            svc?.let {
                it.tapByText("Call", false) || it.tapByText("কল", false) || it.tapByText("SIM 1", false)
            }
            ok("dialed" to cleanNum, "contact" to resolvedName, "method" to "dialer")
        } catch (e: Exception) {
            fail("কল করা যায়নি: ${e.javaClass.simpleName}")
        }
    }

    private fun findContactNumber(query: String): Pair<String, String>? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val cr = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        var bestMatch: Pair<String, String>? = null
        cr.query(uri, projection, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val name = if (nameIdx >= 0) cursor.getString(nameIdx).orEmpty() else ""
                val num = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else ""
                if (name.isBlank() || num.isBlank()) continue
                if (name.equals(query, ignoreCase = true)) {
                    return name to num
                }
                if (bestMatch == null && (name.contains(query, ignoreCase = true) || query.contains(name, ignoreCase = true))) {
                    bestMatch = name to num
                }
            }
        }
        return bestMatch
    }

    // ---------- গান ও মিউজিক অটো-প্লে ----------

    private suspend fun playSong(args: JSONObject): JSONObject {
        val query = args.optString("query").trim()
        if (query.isEmpty()) return fail("গানের নাম দেওয়া হয়নি।")
        val platform = args.optString("platform", "youtube").lowercase()
        val rawUrl = if (platform == "ytmusic") {
            "https://music.youtube.com/search?q=$query"
        } else {
            "https://www.youtube.com/results?search_query=$query"
        }
        val opened = openUrl(rawUrl)
        if (!opened.optBoolean("ok")) return opened

        // পেজ লোড হওয়ার পর প্রথম ভিডিও/গানটি অটো-প্লে করার চেষ্টা
        delay(2600)
        val svc = JarvisAccessibilityService.instance
        var autoPlayed = false
        if (svc != null) {
            val firstWord = query.split(" ").firstOrNull { it.length >= 2 } ?: query
            autoPlayed = svc.tapByText(firstWord, false)
            if (!autoPlayed) {
                val dm = context.resources.displayMetrics
                autoPlayed = svc.tapAt((dm.widthPixels * 0.5f).toInt(), (dm.heightPixels * 0.38f).toInt())
            }
        } else if (rootReady()) {
            val dm = context.resources.displayMetrics
            val tapOp = RootOperation.parse("root_tap", mapOf(
                "x" to ((dm.widthPixels * 0.5f).toInt()).toString(),
                "y" to ((dm.heightPixels * 0.38f).toInt()).toString()
            ))
            if (tapOp != null) autoPlayed = rootExecutor.run(tapOp).ok
        }
        return ok("song_query" to query, "auto_triggered" to autoPlayed)
    }

    // ---------- ট্যাব ও অ্যাপ সুইচিং নিয়ন্ত্রণ ----------

    private suspend fun controlTab(args: JSONObject): JSONObject {
        val action = args.optString("action").lowercase().trim()
        val svc = JarvisAccessibilityService.instance
        return when (action) {
            "switch_last_app", "switch_app" -> {
                if (svc != null) {
                    svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
                    delay(350)
                    svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
                    ok("action" to "switched_last_app")
                } else if (rootReady()) {
                    RootOperation.parse("key_event", mapOf("key" to "APP_SWITCH"))?.let {
                        rootExecutor.run(it); delay(350); rootExecutor.run(it)
                    }
                    ok("action" to "switched_last_app_root")
                } else fail("Accessibility বা Root চালু নেই।")
            }
            "recents" -> {
                if (svc != null && svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS)) ok("action" to "recents")
                else if (rootReady()) {
                    RootOperation.parse("key_event", mapOf("key" to "APP_SWITCH"))?.let { rootExecutor.run(it) }
                    ok("action" to "recents_root")
                } else fail("রিসেন্ট ট্যাব খোলা যায়নি।")
            }
            "split_screen" -> {
                if (svc != null && Build.VERSION.SDK_INT >= 24 && svc.global(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)) {
                    ok("action" to "split_screen")
                } else fail("স্প্লিট স্ক্রিন চালু করা যায়নি।")
            }
            "new_tab" -> {
                val tapped = svc?.let { it.tapByText("New tab", false) || it.tapByText("নতুন ট্যাব", false) || it.tapByText("+", false) } ?: false
                ok("action" to "new_tab", "tapped" to tapped)
            }
            "close_tab" -> {
                val tapped = svc?.let { it.tapByText("Close tab", false) || it.tapByText("ট্যাব বন্ধ", false) } ?: false
                ok("action" to "close_tab", "tapped" to tapped)
            }
            "next_tab" -> {
                val swiped = svc?.swipe("left") ?: false
                ok("action" to "next_tab", "swiped" to swiped)
            }
            "prev_tab" -> {
                val swiped = svc?.swipe("right") ?: false
                ok("action" to "prev_tab", "swiped" to swiped)
            }
            else -> fail("অজানা ট্যাব অ্যাকশন: $action")
        }
    }

    // ---------- Accessibility ----------

    private suspend fun accessibilityTool(name: String, args: JSONObject): JSONObject {
        val svc = JarvisAccessibilityService.instance ?: return fail(context.getString(R.string.a11y_not_enabled))
        return when (name) {
            "get_screen" -> {
                val nodes = svc.snapshot()
                if (nodes.isEmpty()) fail("স্ক্রিনের কিছু পড়া যায়নি (অ্যাপটি সুরক্ষিত হতে পারে; প্রয়োজনে Root টুল ব্যবহার করুন)।")
                else {
                    val arr = JSONArray()
                    nodes.forEach {
                        val o = JSONObject().put("text", it.text).put("desc", it.desc).put("type", it.cls)
                            .put("clickable", it.clickable).put("editable", it.editable).put("scrollable", it.scrollable)
                        val b = it.bounds.split(',').mapNotNull { s -> s.toIntOrNull() }
                        if (b.size == 4) o.put("center", JSONArray().put((b[0] + b[2]) / 2).put((b[1] + b[3]) / 2))
                        arr.put(o)
                    }
                    ok("nodes" to arr, "count" to nodes.size)
                }
            }
            "tap_text", "long_press_text" -> {
                val label = args.optString("text")
                if (label.isBlank()) return fail("text দেওয়া হয়নি।")
                verified(svc) { svc.tapByText(label, longPress = name == "long_press_text") }
            }
            "tap_xy" -> {
                val x = args.optInt("x", -1)
                val y = args.optInt("y", -1)
                if (x < 0 || y < 0) return fail("x ও y দিন।")
                verified(svc) { svc.tapAt(x, y) }
            }
            "scroll" -> {
                val forward = args.optString("direction").lowercase() != "up"
                verified(svc) { svc.scroll(forward) }
            }
            "swipe" -> verified(svc) { svc.swipe(args.optString("direction").lowercase()) }
            "type_text" -> typeText(svc, args)
            "press_system" -> {
                val action = when (args.optString("button").lowercase()) {
                    "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                    "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                    "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                    "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                    "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                    else -> return fail("অজানা বোতাম।")
                }
                verified(svc) { svc.global(action) }
            }
            else -> fail("অজানা টুল: $name")
        }
    }

    /** কাজ চালিয়ে স্ক্রিনের স্বাক্ষর আগে-পরে মিলিয়ে ফলাফল জানায়। */
    private suspend fun verified(svc: JarvisAccessibilityService, action: suspend () -> Boolean): JSONObject {
        val before = svc.signature()
        if (!action()) return fail("কাজটি করা যায়নি (এলিমেন্ট পাওয়া যায়নি বা Android অনুমতি দেয়নি)।")
        delay(700)
        return ok("screen_changed" to (svc.signature() != before))
    }

    private suspend fun typeText(svc: JarvisAccessibilityService, args: JSONObject): JSONObject {
        val text = args.optString("text")
        if (text.isEmpty()) return fail("text দেওয়া হয়নি।")
        val submit = args.optBoolean("submit", false)
        val before = svc.signature()
        var allowPassword = false
        var result = JarvisAccessibilityService.TypeResult.NO_FIELD
        for (attempt in 0 until 6) {
            result = svc.typeText(text, allowPassword)
            if (result == JarvisAccessibilityService.TypeResult.PASSWORD_BLOCKED) {
                if (!confirm("একটি পাসওয়ার্ড ঘরে লেখা হবে। অনুমতি দেবেন?")) return fail("ব্যবহারকারী অনুমতি দেননি।")
                allowPassword = true
                result = svc.typeText(text, true)
            }
            if (result != JarvisAccessibilityService.TypeResult.NO_FIELD) break
            delay(400)
        }
        when (result) {
            JarvisAccessibilityService.TypeResult.OK -> {}
            JarvisAccessibilityService.TypeResult.NO_FIELD -> return fail("কোনো লেখার ঘর পাওয়া যায়নি। আগে ঘরটিতে ট্যাপ করুন।")
            else -> return fail("লেখা যায়নি।")
        }
        var submitted = false
        if (submit) {
            delay(300)
            submitted = svc.imeEnter()
            if (!submitted && rootReady()) {
                RootOperation.parse("key_event", mapOf("key" to "ENTER"))?.let { submitted = rootExecutor.run(it).ok }
            }
        }
        delay(700)
        return ok("typed" to true, "submitted" to submitted, "screen_changed" to (svc.signature() != before))
    }

    // ---------- অ্যাপ/লিংক ----------

    private suspend fun rootReady(): Boolean =
        store.rootEnabled && (rootChecker.status == RootStatus.GRANTED || rootChecker.check().status == RootStatus.GRANTED)

    private suspend fun openUrl(raw: String): JSONObject {
        val url = RootOperation.normalizeUrl(raw)
        if (!(url.startsWith("https://") || url.startsWith("http://"))) return fail("শুধু http/https লিংক খোলা যায়।")
        val svc = JarvisAccessibilityService.instance
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val before = svc?.signature()
        var started = try { (svc ?: context).startActivity(intent); true } catch (e: Exception) { false }
        delay(1800)
        var changed = svc?.let { it.signature() != before } ?: started
        if ((!started || !changed) && rootReady()) {
            RootOperation.parse("open_url", mapOf("url" to url))?.let { started = rootExecutor.run(it).ok }
            delay(1800)
            changed = svc?.let { it.signature() != before } ?: started
        }
        return if (started) ok("opened" to url, "screen_changed" to changed) else fail("লিংক খোলা যায়নি।")
    }

    private suspend fun openApp(query: String): JSONObject {
        if (query.isBlank()) return fail("অ্যাপের নাম দেওয়া হয়নি।")
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0)
            .map { it to it.loadLabel(pm).toString() }
            .let { list -> list.firstOrNull { it.second.equals(query, true) } ?: list.firstOrNull { it.second.contains(query, true) } }
            ?: return fail("\"$query\" নামের অ্যাপ পাওয়া যায়নি।")
        val pkg = match.first.activityInfo.packageName
        val intent = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return fail("অ্যাপটি খোলা যায়নি।")
        val svc = JarvisAccessibilityService.instance
        val before = svc?.signature()
        var started = try { (svc ?: context).startActivity(intent); true } catch (e: Exception) { false }
        delay(1500)
        var changed = svc?.let { it.signature() != before } ?: started
        if ((!started || !changed) && rootReady()) {
            RootOperation.parse("launch_app", mapOf("package" to pkg))?.let { started = rootExecutor.run(it).ok }
            delay(1500)
            changed = svc?.let { it.signature() != before } ?: started
        }
        return if (started) ok("opened" to match.second, "screen_changed" to changed) else fail("Android অ্যাপ খুলতে দেয়নি।")
    }

    private fun setVolume(percent: Int): JSONObject {
        if (percent !in 0..100) return fail("০ থেকে ১০০ এর মধ্যে দিন।")
        return try {
            val am = context.getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (percent * max / 100.0).roundToInt(), 0)
            ok("percent" to percent)
        } catch (e: Exception) {
            fail("ভলিউম বদলানো যায়নি।")
        }
    }

    // ---------- হাই-লেভেল Root ----------

    private suspend fun rootTool(name: String, args: JSONObject): JSONObject {
        if (!store.rootEnabled) return fail("সেটিংসে Root ব্যবহার বন্ধ আছে। Accessibility দিয়ে চেষ্টা করুন।")
        if (!rootReady()) return fail("Root পাওয়া যায়নি বা অনুমতি নেই। Accessibility দিয়ে চেষ্টা করুন।")
        val (op, map) = when (name) {
            "wifi_connect" -> "wifi_connect" to mapOf(
                "ssid" to args.optString("ssid"),
                "security" to args.optString("security", "wpa2"),
                "password" to args.optString("password"),
            )
            "set_toggle" -> ("set_" + args.optString("name")) to mapOf("enabled" to args.optBoolean("enabled").toString())
            "set_brightness" -> "set_brightness" to mapOf("level" to args.optInt("level", -1).toString())
            "key_event" -> "key_event" to mapOf("key" to args.optString("key"))
            "force_stop_app" -> "force_stop" to mapOf("package" to args.optString("package"))
            "clear_app_cache" -> "clear_cache" to mapOf("package" to args.optString("package", "all"))
            "root_tap" -> "root_tap" to mapOf("x" to args.optInt("x", -1).toString(), "y" to args.optInt("y", -1).toString())
            "root_swipe" -> "root_swipe" to mapOf(
                "x1" to args.optInt("x1", -1).toString(),
                "y1" to args.optInt("y1", -1).toString(),
                "x2" to args.optInt("x2", -1).toString(),
                "y2" to args.optInt("y2", -1).toString(),
                "duration" to args.optInt("duration", 300).toString(),
            )
            "root_type" -> "root_text" to mapOf("text" to args.optString("text"))
            "take_screenshot" -> "take_screenshot" to emptyMap()
            "power_control" -> "power_control" to mapOf("mode" to args.optString("mode"))
            "run_root_shell" -> "custom_shell" to mapOf("command" to args.optString("command"))
            else -> {
                val kind = args.optString("kind")
                val kOp = when (kind) {
                    "apps" -> "list_user_apps"
                    "perf" -> "system_perf"
                    else -> "battery_info"
                }
                kOp to emptyMap<String, String>()
            }
        }
        val parsed = RootOperation.parse(op, map) ?: return fail("অনুমোদিত নয় এমন অপারেশন বা অবৈধ আর্গুমেন্ট।")
        val needsPrompt = parsed.requiresConfirmation && (!store.autoApproveRoot || op == "power_control")
        if (needsPrompt && !confirm("Root দিয়ে: ${parsed.describeBn()}। অনুমতি দেবেন?")) {
            return fail("ব্যবহারকারী অনুমতি দেননি।")
        }
        val r = rootExecutor.run(parsed)
        return JSONObject().put("ok", r.ok).put("exit_code", r.exitCode).put("output", r.output).apply {
            if (!r.ok) put("error", r.error)
        }
    }

    private companion object {
        val LABELS = mapOf(
            "call_phone" to "কল করছি…",
            "play_song" to "গান বাজাচ্ছি…",
            "control_tab" to "ট্যাব বদলাচ্ছি…",
            "get_screen" to "স্ক্রিন দেখছি…",
            "tap_text" to "ট্যাপ করছি…", "long_press_text" to "ট্যাপ করছি…", "tap_xy" to "ট্যাপ করছি…",
            "scroll" to "স্ক্রল করছি…", "swipe" to "সোয়াইপ করছি…",
            "type_text" to "লিখছি…", "press_system" to "বোতাম চাপছি…",
            "open_app" to "অ্যাপ খুলছি…", "open_url" to "লিংক খুলছি…", "wait" to "অপেক্ষা করছি…",
            "set_volume" to "ভলিউম বদলাচ্ছি…",
            "wifi_connect" to "Wi-Fi সংযোগ করছি…", "set_toggle" to "সেটিংস বদলাচ্ছি…",
            "set_brightness" to "উজ্জ্বলতা বদলাচ্ছি…", "key_event" to "বোতাম চাপছি…",
            "force_stop_app" to "অ্যাপ বন্ধ করছি…", "clear_app_cache" to "র‍্যাম ও ক্যাশ পরিষ্কার করছি…",
            "root_tap" to "রুট ট্যাপ করছি…", "root_swipe" to "রুট সোয়াইপ করছি…", "root_type" to "রুট টাইপ করছি…",
            "take_screenshot" to "স্ক্রিনশট নিচ্ছি…", "power_control" to "পাওয়ার কমান্ড চালাচ্ছি…",
            "run_root_shell" to "রুট শেল চালাচ্ছি…", "root_info" to "তথ্য পড়ছি…",
        )
    }
}
