package com.anas.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.anas.ai.R
import com.anas.ai.automation.AutomationCapabilityChecker
import com.anas.ai.core.AssistantState
import com.anas.ai.core.Confirmation
import com.anas.ai.core.RootStatus
import com.anas.ai.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()
    private val adapter = MessageAdapter()
    private var dialog: AlertDialog? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.RECORD_AUDIO] == true) vm.toggleSession()
        else b.tvError.apply { text = getString(R.string.err_no_mic); visibility = View.VISIBLE }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.rvMessages.layoutManager = LinearLayoutManager(this)
        b.rvMessages.adapter = adapter

        b.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        b.btnAutomation.setOnClickListener { vm.toggleAutomation() }
        b.btnMic.setOnClickListener {
            if (vm.state.value != AssistantState.OFFLINE) vm.toggleSession() else ensurePermissionThenStart()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.state.collect(::renderState) }
                launch { vm.level.collect { b.orb.level = it } }
                launch {
                    vm.messages.collect { list ->
                        adapter.submitList(list) { if (list.isNotEmpty()) b.rvMessages.scrollToPosition(list.size - 1) }
                    }
                }
                launch {
                    vm.error.collect {
                        b.tvError.text = it.orEmpty()
                        b.tvError.visibility = if (it.isNullOrEmpty()) View.GONE else View.VISIBLE
                    }
                }
                launch { vm.confirmation.collect(::renderConfirmation) }
                launch {
                    vm.automationPaused.collect {
                        b.btnAutomation.setText(if (it) R.string.btn_auto_resume else R.string.btn_auto_stop)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val a11y = getString(if (AutomationCapabilityChecker.isAccessibilityEnabled(this)) R.string.on else R.string.off)
        val root = getString(
            when (vm.engine.rootChecker.status) {
                RootStatus.UNKNOWN -> R.string.root_unknown
                RootStatus.NOT_AVAILABLE -> R.string.root_na
                RootStatus.DENIED -> R.string.root_denied
                RootStatus.GRANTED -> R.string.root_granted
            },
        )
        b.tvCaps.text = getString(R.string.caps_fmt, a11y, root)
    }

    private fun ensurePermissionThenStart() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) vm.toggleSession() else permLauncher.launch(need.toTypedArray())
    }

    private fun renderState(s: AssistantState) {
        b.orb.state = s
        b.tvStatus.setText(
            when (s) {
                AssistantState.OFFLINE -> R.string.status_offline
                AssistantState.CONNECTING -> R.string.status_connecting
                AssistantState.LISTENING -> R.string.status_listening
                AssistantState.THINKING -> R.string.status_thinking
                AssistantState.SPEAKING -> R.string.status_speaking
            },
        )
        b.btnMic.setText(if (s == AssistantState.OFFLINE) R.string.btn_start else R.string.btn_end)
        b.btnMic.setBackgroundResource(if (s == AssistantState.OFFLINE) R.drawable.bg_btn_primary else R.drawable.bg_btn_stop)
    }

    private fun renderConfirmation(c: Confirmation?) {
        dialog?.dismiss()
        dialog = null
        if (c == null) return
        dialog = AlertDialog.Builder(this)
            .setTitle(R.string.conf_title)
            .setMessage(c.message)
            .setCancelable(false)
            .setPositiveButton(R.string.conf_allow) { _, _ -> c.result.complete(true) }
            .setNegativeButton(R.string.conf_cancel) { _, _ -> c.result.complete(false) }
            .show()
    }
}
