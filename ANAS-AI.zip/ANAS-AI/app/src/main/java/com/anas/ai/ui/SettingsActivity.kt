package com.anas.ai.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.anas.ai.AnasApp
import com.anas.ai.R
import com.anas.ai.automation.AutomationCapabilityChecker
import com.anas.ai.core.Personality
import com.anas.ai.core.RootStatus
import com.anas.ai.core.SecureKeyStore
import com.anas.ai.databinding.ActivitySettingsBinding
import com.anas.ai.gemini.GeminiKeyValidator
import com.anas.ai.gemini.KeyValidation
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var b: ActivitySettingsBinding
    private val engine by lazy { (application as AnasApp).engine }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.etModel.setText(engine.store.model)
        refreshKeyState()

        b.btnSaveKey.setOnClickListener { validateAndSave() }

        val items = Personality.entries
        b.spPersonality.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items.map { it.labelBn })
        b.spPersonality.setSelection(items.indexOf(engine.store.personality))
        b.spPersonality.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                engine.store.personality = items[pos]
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        b.btnA11y.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        b.switchRoot.isChecked = engine.store.rootEnabled
        b.switchRoot.setOnCheckedChangeListener { _, checked -> engine.store.rootEnabled = checked }
        b.btnRootCheck.setOnClickListener {
            b.tvRootState.setText(R.string.root_checking)
            lifecycleScope.launch {
                engine.rootChecker.check()
                refreshRoot()
            }
        }
        b.btnClearHistory.setOnClickListener {
            engine.repo.clear()
            b.tvKeyResult.setText(R.string.history_cleared)
        }
    }

    override fun onResume() {
        super.onResume()
        val state = when {
            AutomationCapabilityChecker.isAccessibilityConnected() -> R.string.a11y_connected
            AutomationCapabilityChecker.isAccessibilityEnabled(this) -> R.string.a11y_enabled_idle
            else -> R.string.a11y_disabled
        }
        b.tvA11yState.text = getString(R.string.a11y_state_fmt, getString(state))
        refreshRoot()
    }

    private fun refreshRoot() {
        val r = engine.rootChecker.lastReport
        val label = getString(
            when (r.status) {
                RootStatus.UNKNOWN -> R.string.root_unknown
                RootStatus.NOT_AVAILABLE -> R.string.root_na
                RootStatus.DENIED -> R.string.root_denied
                RootStatus.GRANTED -> R.string.root_granted
            },
        )
        val extra = if (r.status == RootStatus.UNKNOWN) "" else " (Android API ${r.sdk}, SELinux: ${r.selinux})"
        b.tvRootState.text = getString(R.string.root_state_fmt, label) + extra
    }

    private fun refreshKeyState() {
        val key = engine.store.apiKey
        b.tvKeyState.text = if (key == null) getString(R.string.key_none)
        else getString(R.string.key_saved_fmt, SecureKeyStore.mask(key))
    }

    private fun validateAndSave() {
        val key = b.etApiKey.text.toString().trim().ifEmpty { engine.store.apiKey.orEmpty() }
        val model = b.etModel.text.toString().trim().ifEmpty { SecureKeyStore.DEFAULT_MODEL }
        if (key.isEmpty()) { b.tvKeyResult.setText(R.string.key_empty); return }
        if (!engine.store.isSecureAvailable) { b.tvKeyResult.setText(R.string.key_secure_unavailable); return }
        b.tvKeyResult.setText(R.string.validating)
        b.btnSaveKey.isEnabled = false
        lifecycleScope.launch {
            val result = GeminiKeyValidator.validate(engine.http, key, model)
            when (result) {
                KeyValidation.Valid -> { save(key, model); b.tvKeyResult.setText(R.string.key_ok) }
                KeyValidation.ValidModelMissing -> { save(key, model); b.tvKeyResult.setText(R.string.key_ok_model_missing) }
                is KeyValidation.Invalid -> b.tvKeyResult.text = getString(R.string.key_invalid, result.message)
                is KeyValidation.NetworkError -> b.tvKeyResult.text = getString(R.string.err_network, result.message)
            }
            b.btnSaveKey.isEnabled = true
        }
    }

    private fun save(key: String, model: String) {
        engine.store.apiKey = key
        engine.store.model = model
        b.etApiKey.setText("")
        refreshKeyState()
    }
}
