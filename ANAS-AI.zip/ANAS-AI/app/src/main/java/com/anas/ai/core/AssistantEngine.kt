package com.anas.ai.core

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.anas.ai.R
import com.anas.ai.audio.AudioPlayer
import com.anas.ai.audio.AudioRecorder
import com.anas.ai.automation.AutomationCapabilityChecker
import com.anas.ai.automation.AutomationCoordinator
import com.anas.ai.automation.ToolDispatcher
import com.anas.ai.gemini.FunctionResponse
import com.anas.ai.gemini.GeminiLiveClient
import com.anas.ai.gemini.LiveEvent
import com.anas.ai.root.RootCapabilityChecker
import com.anas.ai.root.RootCommandExecutor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * সেশনের কেন্দ্র: Gemini Live সংযোগ, মাইক/স্পিকার, অবস্থা (state), পুনঃসংযোগ, barge-in ও টুল কল।
 * Application-স্কোপে থাকে, তাই অ্যাপ ব্যাকগ্রাউন্ডে গেলেও (ফোরগ্রাউন্ড সার্ভিসসহ) সেশন চলতে পারে।
 */
class AssistantEngine(private val app: Application) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val http: OkHttpClient = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    val store = SecureKeyStore(app)
    val repo = ConversationRepository(app)
    val rootChecker = RootCapabilityChecker()
    private val rootExecutor = RootCommandExecutor()
    val coordinator = AutomationCoordinator(app, rootChecker, rootExecutor, store) { requestConfirmation(it) }

    private val client = GeminiLiveClient(http)
    private val recorder = AudioRecorder()
    private val player = AudioPlayer { lvl -> if (_state.value == AssistantState.SPEAKING) _level.value = lvl }

    private val _state = MutableStateFlow(AssistantState.OFFLINE)
    val state: StateFlow<AssistantState> = _state.asStateFlow()
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _error.asStateFlow()
    private val _confirmation = MutableStateFlow<Confirmation?>(null)
    val confirmation: StateFlow<Confirmation?> = _confirmation.asStateFlow()

    @Volatile private var sessionActive = false
    @Volatile private var spoke = false
    @Volatile private var lastVoice = 0L
    private var bargeCount = 0
    private var attempts = 0
    private var reconnectJob: Job? = null

    init {
        scope.launch { client.events.collect { handle(it) } }
        scope.launch {
            // "ভাবছি" অবস্থা: ব্যবহারকারী কথা বলে ~০.৮ সেকেন্ড চুপ থাকলে।
            while (true) {
                delay(200)
                if (sessionActive && _state.value == AssistantState.LISTENING && spoke &&
                    SystemClock.elapsedRealtime() - lastVoice > 800
                ) _state.value = AssistantState.THINKING
            }
        }
    }

    // ---------- সেশন নিয়ন্ত্রণ ----------

    fun startSession() {
        if (sessionActive) return
        if (store.apiKey == null) { _error.value = app.getString(R.string.err_no_key); return }
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _error.value = app.getString(R.string.err_no_mic); return
        }
        _error.value = null
        sessionActive = true
        attempts = 0
        client.resumptionHandle = null
        VoiceService.start(app)
        player.start(scope)
        scope.launch { connect() }
    }

    fun stopSession(message: String? = null) {
        sessionActive = false
        reconnectJob?.cancel()
        recorder.stop()
        client.close()
        player.stop()
        spoke = false
        _level.value = 0f
        _state.value = AssistantState.OFFLINE
        _confirmation.value?.result?.complete(false)
        repo.endTurn()
        VoiceService.stop(app)
        if (message != null) _error.value = message
    }

    private suspend fun connect() {
        val key = store.apiKey ?: return stopSession(app.getString(R.string.err_no_key))
        _state.value = AssistantState.CONNECTING
        val a11y = AutomationCapabilityChecker.isAccessibilityEnabled(app)
        val rootOn = store.rootEnabled && rootChecker.status == RootStatus.GRANTED
        client.connect(
            key, store.model,
            SystemPromptBuilder.build(store.personality, a11y, rootOn),
            ToolDispatcher.declarations(rootOn),
        )
    }

    private fun scheduleReconnect() {
        if (reconnectJob?.isActive == true) return
        reconnectJob = scope.launch {
            while (sessionActive && attempts < MAX_ATTEMPTS) {
                attempts++
                _state.value = AssistantState.CONNECTING
                delay(minOf(1000L shl (attempts - 1), 15_000L))
                if (!sessionActive) return@launch
                connect()
                val connected = withTimeoutOrNull(10_000) { _state.first { it != AssistantState.CONNECTING } }
                if (connected != null) return@launch
            }
            if (sessionActive) stopSession(app.getString(R.string.err_reconnect))
        }
    }

    // ---------- ইভেন্ট ----------

    private fun handle(e: LiveEvent) {
        when (e) {
            LiveEvent.Connected -> {
                attempts = 0
                _error.value = null
                if (!recorder.start(scope, ::onMic)) { stopSession(app.getString(R.string.err_mic_init)); return }
                _state.value = AssistantState.LISTENING
            }
            is LiveEvent.Audio -> {
                if (_state.value != AssistantState.SPEAKING) _state.value = AssistantState.SPEAKING
                spoke = false
                player.enqueue(e.pcm)
            }
            LiveEvent.Interrupted -> {
                player.flush()
                repo.endTurn()
                if (sessionActive) _state.value = AssistantState.LISTENING
            }
            LiveEvent.TurnComplete -> scope.launch {
                while (player.pendingMs() > 0) delay(50)
                delay(250)
                repo.endTurn()
                if (sessionActive && _state.value == AssistantState.SPEAKING) _state.value = AssistantState.LISTENING
            }
            is LiveEvent.InputText -> repo.stream(Role.USER, e.text)
            is LiveEvent.OutputText -> repo.stream(Role.AI, e.text)
            is LiveEvent.ToolCall -> handleTools(e)
            LiveEvent.GoAway -> if (sessionActive) {
                // সেশন নবায়ন: resumption handle দিয়ে নতুন সংযোগ।
                client.close()
                scheduleReconnect()
            }
            is LiveEvent.Closed -> if (sessionActive) {
                if (e.fatal) {
                    val msg = if (e.code in 400..499) app.getString(R.string.err_auth, e.code)
                    else app.getString(R.string.err_server_closed, e.code, e.reason)
                    stopSession(msg)
                } else scheduleReconnect()
            }
        }
    }

    private fun onMic(data: ByteArray, lvl: Float) {
        val st = _state.value
        if (st != AssistantState.SPEAKING) _level.value = lvl
        val now = SystemClock.elapsedRealtime()
        if (lvl > 0.06f) {
            lastVoice = now
            if (st == AssistantState.LISTENING) spoke = true
        }
        // দ্রুত স্থানীয় barge-in: AI বলার সময় জোরালো কণ্ঠ পেলে অডিও থামানো (সার্ভারও interrupted পাঠায়)।
        if (st == AssistantState.SPEAKING) {
            if (lvl > 0.35f) {
                if (++bargeCount >= 3) {
                    bargeCount = 0
                    player.flush()
                    _state.value = AssistantState.LISTENING
                    spoke = true
                    lastVoice = now
                }
            } else bargeCount = 0
        }
        client.sendAudio(data)
    }

    private fun handleTools(e: LiveEvent.ToolCall) {
        _state.value = AssistantState.THINKING
        scope.launch(Dispatchers.IO) {
            val responses = e.calls.map { c ->
                val r = try {
                    coordinator.execute(c.name, c.args)
                } catch (ce: CancellationException) {
                    throw ce
                } catch (ex: Exception) {
                    JSONObject().put("ok", false).put("error", ex.javaClass.simpleName)
                }
                repo.addSystem("⚙ ${c.name}: " + if (r.optBoolean("ok")) "সফল" else "ব্যর্থ — " + r.optString("error"))
                FunctionResponse(c.id, c.name, r)
            }
            client.sendToolResponses(responses)
        }
    }

    // ---------- নিশ্চিতকরণ ----------

    private suspend fun requestConfirmation(message: String): Boolean {
        val c = Confirmation(message)
        _confirmation.value = c
        VoiceService.notifyConfirmation(app)
        val granted = withTimeoutOrNull(60_000) { c.result.await() } ?: false
        _confirmation.value = null
        return granted
    }

    private companion object { const val MAX_ATTEMPTS = 5 }
}
