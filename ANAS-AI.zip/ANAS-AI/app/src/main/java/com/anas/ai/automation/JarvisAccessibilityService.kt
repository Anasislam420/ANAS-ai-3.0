package com.anas.ai.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.anas.ai.AnasApp
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * ব্যবহারকারীর স্পষ্ট অনুমতিতে (Android Settings থেকে চালু করা) দৃশ্যমান স্ক্রিন পড়া ও কাজ করা।
 * সব অ্যাপের সব UI দেখা যায় না (FLAG_SECURE, কাস্টম রেন্ডারিং, গেম ইত্যাদি) — সেক্ষেত্রে ব্যর্থতা জানানো হয়।
 * এখান থেকেই ভাসমান ম্যাস্কট/নিশ্চিতকরণ overlay দেখানো হয় (TYPE_ACCESSIBILITY_OVERLAY — আলাদা অনুমতি লাগে না)।
 */
class JarvisAccessibilityService : AccessibilityService() {

    data class UiNode(
        val text: String,
        val desc: String,
        val id: String,
        val cls: String,
        val clickable: Boolean,
        val editable: Boolean,
        val scrollable: Boolean,
        val bounds: String,
    )

    enum class TypeResult { OK, NO_FIELD, PASSWORD_BLOCKED, FAILED }

    private var overlay: OverlayController? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        try {
            val app = application as AnasApp
            overlay = OverlayController(this, app.engine, app).also { it.start() }
        } catch (_: Exception) { /* overlay ছাড়াও সার্ভিস কাজ করবে */ }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        instance = null
        overlay?.stop()
        overlay = null
    }

    // ---------- পড়া ----------

    fun snapshot(max: Int = 80): List<UiNode> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = ArrayList<UiNode>()
        walk(root, out, max)
        return out
    }

    private fun walk(node: AccessibilityNodeInfo, out: MutableList<UiNode>, max: Int) {
        if (out.size >= max) return
        if (node.isVisibleToUser) {
            val text = if (node.isPassword) "[গোপন]" else node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            val hint = if (Build.VERSION.SDK_INT >= 26 && text.isBlank()) node.hintText?.toString().orEmpty() else ""
            val interesting = text.isNotBlank() || desc.isNotBlank() || hint.isNotBlank() || node.isClickable || node.isEditable
            if (interesting) {
                val r = Rect()
                node.getBoundsInScreen(r)
                out.add(
                    UiNode(
                        (text.ifBlank { hint }).take(120), desc.take(120), node.viewIdResourceName.orEmpty(),
                        node.className?.toString()?.substringAfterLast('.').orEmpty(),
                        node.isClickable, node.isEditable, node.isScrollable,
                        "${r.left},${r.top},${r.right},${r.bottom}",
                    ),
                )
            }
        }
        for (i in 0 until node.childCount) node.getChild(i)?.let { walk(it, out, max) }
    }

    fun signature(): Int = snapshot(200).hashCode()

    // ---------- ট্যাপ/স্ক্রল ----------

    private fun findTarget(label: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val matches = root.findAccessibilityNodeInfosByText(label).filter { it.isVisibleToUser }
        if (matches.isEmpty()) return null
        return matches.firstOrNull {
            it.text?.toString().equals(label, true) || it.contentDescription?.toString().equals(label, true)
        } ?: matches.first()
    }

    private fun clickableAncestor(start: AccessibilityNodeInfo, longPress: Boolean): AccessibilityNodeInfo? {
        var n: AccessibilityNodeInfo? = start
        while (n != null) {
            if (if (longPress) n.isLongClickable else n.isClickable) return n
            n = n.parent
        }
        return null
    }

    fun tapByText(label: String, longPress: Boolean): Boolean {
        val target = findTarget(label) ?: return false
        val clickable = clickableAncestor(target, longPress) ?: return false
        return clickable.performAction(
            if (longPress) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK,
        )
    }

    fun scroll(forward: Boolean): Boolean {
        val node = rootInActiveWindow?.let { findScrollable(it) } ?: return false
        return node.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD,
        )
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findScrollable(c)?.let { return it }
        }
        return null
    }

    // ---------- জেসচার (স্থানাঙ্ক) ----------

    private suspend fun dispatch(path: Path, durationMs: Long): Boolean = suspendCancellableCoroutine { cont ->
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!accepted && cont.isActive) cont.resume(false)
    }

    suspend fun tapAt(x: Int, y: Int): Boolean =
        dispatch(Path().apply { moveTo(x.toFloat(), y.toFloat()) }, 60)

    /** direction = আঙুল যেদিকে সরে: up/down/left/right */
    suspend fun swipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        when (direction) {
            "up" -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.25f) }
            "down" -> { p.moveTo(w / 2, h * 0.25f); p.lineTo(w / 2, h * 0.75f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return dispatch(p, 350)
    }

    // ---------- টাইপ ----------

    /** পাসওয়ার্ড ফিল্ডে লিখতে [allowPassword] true লাগে; কল করার আগে ব্যবহারকারীর সম্মতি নিতে হবে। */
    fun typeText(text: String, allowPassword: Boolean): TypeResult {
        val root = rootInActiveWindow ?: return TypeResult.NO_FIELD
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: findEditable(root)
            ?: return TypeResult.NO_FIELD
        if (field.isPassword && !allowPassword) return TypeResult.PASSWORD_BLOCKED
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) TypeResult.OK else TypeResult.FAILED
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findEditable(c)?.let { return it }
        }
        return null
    }

    /** কীবোর্ডের Enter/Search (Android 11+)। */
    fun imeEnter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
    }
}
