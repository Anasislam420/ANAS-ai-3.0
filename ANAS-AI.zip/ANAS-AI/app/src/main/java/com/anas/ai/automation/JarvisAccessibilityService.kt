package com.anas.ai.automation

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * ব্যবহারকারীর স্পষ্ট অনুমতিতে (Android Settings থেকে চালু করা) দৃশ্যমান স্ক্রিন পড়া ও সীমিত কিছু কাজ করা।
 * সব অ্যাপের সব UI দেখা যায় না (FLAG_SECURE, কাস্টম রেন্ডারিং, গেম ইত্যাদি) — সেক্ষেত্রে ব্যর্থতা জানানো হয়।
 */
class JarvisAccessibilityService : AccessibilityService() {

    data class UiNode(
        val text: String,
        val desc: String,
        val id: String,
        val cls: String,
        val clickable: Boolean,
        val editable: Boolean,
        val scrollable: Boolean,
        val bounds: String,
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* পোলিং-ভিত্তিক; ইভেন্ট প্রয়োজন নেই */ }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun snapshot(max: Int = 80): List<UiNode> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = ArrayList<UiNode>()
        walk(root, out, max)
        return out
    }

    private fun walk(node: AccessibilityNodeInfo, out: MutableList<UiNode>, max: Int) {
        if (out.size >= max) return
        if (node.isVisibleToUser) {
            val text = if (node.isPassword) "[গোপন]" else node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            val interesting = text.isNotBlank() || desc.isNotBlank() || node.isClickable || node.isEditable
            if (interesting) {
                val r = Rect()
                node.getBoundsInScreen(r)
                out.add(
                    UiNode(
                        text.take(120), desc.take(120), node.viewIdResourceName.orEmpty(),
                        node.className?.toString()?.substringAfterLast('.').orEmpty(),
                        node.isClickable, node.isEditable, node.isScrollable,
                        "${r.left},${r.top},${r.right},${r.bottom}",
                    ),
                )
            }
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { walk(it, out, max) }
        }
    }

    /** স্ক্রিন বদলেছে কি না যাচাইয়ের জন্য ছোট স্বাক্ষর। */
    fun signature(): Int = snapshot(200).hashCode()

    private fun findTarget(label: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val matches = root.findAccessibilityNodeInfosByText(label).filter { it.isVisibleToUser }
        if (matches.isEmpty()) return null
        return matches.firstOrNull {
            it.text?.toString().equals(label, true) || it.contentDescription?.toString().equals(label, true)
        } ?: matches.first()
    }

    private fun clickableAncestor(start: AccessibilityNodeInfo, longPress: Boolean): AccessibilityNodeInfo? {
        var n: AccessibilityNodeInfo? = start
        while (n != null) {
            if (if (longPress) n.isLongClickable else n.isClickable) return n
            n = n.parent
        }
        return null
    }

    fun tapByText(label: String, longPress: Boolean): Boolean {
        val target = findTarget(label) ?: return false
        val clickable = clickableAncestor(target, longPress) ?: return false
        return clickable.performAction(
            if (longPress) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK,
        )
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        return node.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD,
        )
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findScrollable(c)?.let { return it }
        }
        return null
    }

    /** ফোকাসড ইনপুট ফিল্ডে, না থাকলে প্রথম সম্পাদনাযোগ্য ফিল্ডে লেখে। পাসওয়ার্ড ফিল্ডে কখনো লেখে না। */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: findEditable(root)
            ?: return false
        if (field.isPassword) return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findEditable(c)?.let { return it }
        }
        return null
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
    }
}
