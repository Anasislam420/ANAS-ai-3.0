package com.anas.ai.gemini

import android.util.Base64
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject

data class FunctionCall(val id: String, val name: String, val args: JSONObject)
data class FunctionResponse(val id: String, val name: String, val response: JSONObject)

sealed interface LiveEvent {
    data object Connected : LiveEvent
    data class Audio(val pcm: ByteArray) : LiveEvent
    data object Interrupted : LiveEvent
    data object TurnComplete : LiveEvent
    data class InputText(val text: String) : LiveEvent
    data class OutputText(val text: String) : LiveEvent
    data class ToolCall(val calls: List<FunctionCall>) : LiveEvent
    data object GoAway : LiveEvent
    data class Closed(val code: Int, val reason: String, val fatal: Boolean) : LiveEvent
}

/** Gemini Live (BidiGenerateContent) WebSocket ক্লায়েন্ট। ইনপুট 16 kHz PCM, আউটপুট 24 kHz PCM। */
class GeminiLiveClient(private val http: OkHttpClient) {

    private val _events = MutableSharedFlow<LiveEvent>(extraBufferCapacity = 1024, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: SharedFlow<LiveEvent> = _events.asSharedFlow()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var ready = false

    /** সেশন পুনরুদ্ধারের হ্যান্ডেল (GoAway/নেটওয়ার্ক বিচ্ছিন্নতার পর কনটেক্সট ধরে রাখে)। */
    @Volatile var resumptionHandle: String? = null

    val isReady: Boolean get() = ready

    fun connect(apiKey: String, model: String, systemPrompt: String, tools: JSONArray, voiceName: String = "Kore") {
        close()
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
        val req = Request.Builder().url(url).header("x-goog-api-key", apiKey).build()
        lateinit var ws: WebSocket
        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(buildSetup(model, systemPrompt, tools, voiceName).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (webSocket === socket) parse(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (webSocket === socket) parse(bytes.utf8())
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (webSocket !== socket) return
                ready = false
                // 1008 = policy violation (সাধারণত অবৈধ কী/মডেল)
                _events.tryEmit(LiveEvent.Closed(code, reason, fatal = code == 1008 || code in 4000..4999))
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (webSocket !== socket) return
                ready = false
                val http = response?.code
                val fatal = http != null && http in 400..499 && http != 429
                _events.tryEmit(LiveEvent.Closed(http ?: -1, if (http != null) "HTTP $http" else t.javaClass.simpleName, fatal))
            }
        }
        ws = http.newWebSocket(req, listener)
        socket = ws
    }

    private fun buildSetup(model: String, systemPrompt: String, tools: JSONArray, voiceName: String): JSONObject {
        val setup = JSONObject()
            .put("model", "models/$model")
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName)),
                        ),
                    ),
            )
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
            .put(
                "sessionResumption",
                JSONObject().apply { resumptionHandle?.let { put("handle", it) } },
            )
        if (tools.length() > 0) {
            setup.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools)))
        }
        return JSONObject().put("setup", setup)
    }

    private fun parse(text: String) {
        val msg = try { JSONObject(text) } catch (e: Exception) { return }

        if (msg.has("setupComplete")) {
            ready = true
            _events.tryEmit(LiveEvent.Connected)
        }
        msg.optJSONObject("sessionResumptionUpdate")?.let {
            if (it.optBoolean("resumable", false)) {
                it.optString("newHandle").takeIf { h -> h.isNotEmpty() }?.let { h -> resumptionHandle = h }
            }
        }
        if (msg.has("goAway")) _events.tryEmit(LiveEvent.GoAway)

        msg.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted", false)) _events.tryEmit(LiveEvent.Interrupted)
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val inline = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
                    if (inline.optString("mimeType").startsWith("audio/")) {
                        _events.tryEmit(LiveEvent.Audio(Base64.decode(inline.getString("data"), Base64.DEFAULT)))
                    }
                }
            }
            sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }
                ?.let { _events.tryEmit(LiveEvent.InputText(it)) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }
                ?.let { _events.tryEmit(LiveEvent.OutputText(it)) }
            if (sc.optBoolean("turnComplete", false)) _events.tryEmit(LiveEvent.TurnComplete)
        }

        msg.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { arr ->
            val calls = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                FunctionCall(o.optString("id"), o.getString("name"), o.optJSONObject("args") ?: JSONObject())
            }
            if (calls.isNotEmpty()) _events.tryEmit(LiveEvent.ToolCall(calls))
        }
    }

    fun sendAudio(pcm16k: ByteArray) {
        if (!ready) return
        val payload = JSONObject().put(
            "realtimeInput",
            JSONObject().put(
                "audio",
                JSONObject()
                    .put("data", Base64.encodeToString(pcm16k, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000"),
            ),
        )
        socket?.send(payload.toString())
    }

    fun sendToolResponses(responses: List<FunctionResponse>) {
        val arr = JSONArray()
        responses.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("response", it.response))
        }
        socket?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", arr)).toString())
    }

    fun close() {
        ready = false
        val s = socket
        socket = null
        s?.close(1000, "client closing")
    }
}
