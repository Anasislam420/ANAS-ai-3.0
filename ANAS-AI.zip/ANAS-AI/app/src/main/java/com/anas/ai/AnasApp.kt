package com.anas.ai

import android.app.Application
import com.anas.ai.core.AssistantEngine

class AnasApp : Application() {
    lateinit var engine: AssistantEngine
        private set

    override fun onCreate() {
        super.onCreate()
        engine = AssistantEngine(this)
    }
}
