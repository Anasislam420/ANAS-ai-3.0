package com.anas.ai

import android.app.Activity
import android.app.Application
import android.os.Bundle
import com.anas.ai.core.AssistantEngine
import kotlinx.coroutines.flow.MutableStateFlow

class AnasApp : Application(), Application.ActivityLifecycleCallbacks {
    lateinit var engine: AssistantEngine
        private set

    /** অ্যাপের কোনো স্ক্রিন সামনে থাকলে true; তখন ভাসমান ম্যাস্কট লুকানো থাকে। */
    val appVisible = MutableStateFlow(false)
    private var started = 0

    override fun onCreate() {
        super.onCreate()
        engine = AssistantEngine(this)
        registerActivityLifecycleCallbacks(this)
    }

    override fun onActivityStarted(activity: Activity) {
        started++
        appVisible.value = true
    }

    override fun onActivityStopped(activity: Activity) {
        started = (started - 1).coerceAtLeast(0)
        if (started == 0) appVisible.value = false
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityResumed(activity: Activity) {}
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {}
}
