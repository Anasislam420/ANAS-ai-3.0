package com.anas.ai.automation

import org.json.JSONArray
import org.json.JSONObject

/** Gemini-কে জানানো ফাংশন ডিক্লারেশন (কল করা, গান বাজানো, ট্যাব কন্ট্রোল ও হাই-লেভেল রুট টুলসসহ)। */
object ToolDispatcher {

    private fun p(type: String, description: String) = JSONObject().put("type", type).put("description", description)

    private fun fn(name: String, description: String, props: Map<String, JSONObject> = emptyMap(), required: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", description)
        if (props.isNotEmpty()) {
            val pr = JSONObject()
            props.forEach { (k, v) -> pr.put(k, v) }
            val schema = JSONObject().put("type", "OBJECT").put("properties", pr)
            if (required.isNotEmpty()) schema.put("required", JSONArray(required))
            o.put("parameters", schema)
        }
        return o
    }

    val ROOT_TOOLS = setOf(
        "wifi_connect", "set_toggle", "set_brightness", "key_event", "force_stop_app",
        "root_info", "root_tap", "root_swipe", "root_type", "clear_app_cache",
        "take_screenshot", "power_control", "run_root_shell"
    )

    fun declarations(rootAvailable: Boolean): JSONArray {
        val arr = JSONArray()
            .put(fn("call_phone", "কাউকে সরাসরি ডিফল্ট ফোন কল করে। কন্টাক্টের নাম (name) বা মোবাইল নাম্বার (number) যেকোনো একটি দিলেই সরাসরি কল যাবে।",
                mapOf(
                    "name" to p("STRING", "কন্টাক্টের নাম (যেমন: আম্মু, বাবা, Rakib, Jahid)"),
                    "number" to p("STRING", "ফোন নাম্বার (যদি সরাসরি নাম্বার বলা হয়)")
                )))
            .put(fn("play_song", "যেকোনো গান ইউটিউব বা মিউজিক অ্যাপে সরাসরি সার্চ করে অটো-প্লে করে।",
                mapOf(
                    "query" to p("STRING", "গানের নাম বা শিল্পীর নাম"),
                    "platform" to p("STRING", "youtube অথবা ytmusic (ডিফল্ট youtube)")
                ), listOf("query")))
            .put(fn("control_tab", "ব্রাউজারের ট্যাব, রিসেন্ট অ্যাপ সুইচিং বা স্প্লিট-স্ক্রিন নিয়ন্ত্রণ করে।",
                mapOf(
                    "action" to p("STRING", "switch_last_app (আগের অ্যাপে যাওয়া), recents (ট্যাব/রিসেন্ট অ্যাপ তালিকা), next_tab, prev_tab, new_tab, close_tab, অথবা split_screen")
                ), listOf("action")))
            .put(fn("get_screen", "বর্তমান স্ক্রিনের দৃশ্যমান লেখা, বোতাম ও তাদের center স্থানাঙ্ক পড়ে। প্রতিটি কাজের পর ফল যাচাইয়ে ব্যবহার করো।"))
            .put(fn("tap_text", "স্ক্রিনে দেখা লেখা/লেবেল অনুযায়ী ট্যাপ করে।", mapOf("text" to p("STRING", "বোতাম বা লেখার লেবেল")), listOf("text")))
            .put(fn("long_press_text", "লেবেল অনুযায়ী লং-প্রেস করে।", mapOf("text" to p("STRING", "লেবেল")), listOf("text")))
            .put(fn("tap_xy", "স্ক্রিনের নির্দিষ্ট পিক্সেল স্থানাঙ্কে ট্যাপ করে (get_screen-এর center থেকে)। tap_text কাজ না করলে ব্যবহার করো।",
                mapOf("x" to p("INTEGER", "x"), "y" to p("INTEGER", "y")), listOf("x", "y")))
            .put(fn("scroll", "তালিকা/পেজ স্ক্রল করে।", mapOf("direction" to p("STRING", "down (নিচে) অথবা up (উপরে)")), listOf("direction")))
            .put(fn("swipe", "আঙুল টেনে সোয়াইপ করে।", mapOf("direction" to p("STRING", "আঙুল যেদিকে সরবে: up, down, left, right")), listOf("direction")))
            .put(fn("type_text", "বর্তমান ইনপুট ঘরে লেখে (ঘর না পেলে কয়েকবার অপেক্ষা করে)। submit=true হলে Enter/Search চাপে।",
                mapOf("text" to p("STRING", "যা লিখতে হবে"), "submit" to p("BOOLEAN", "লেখার পর Enter/Search চাপবে কি না")), listOf("text")))
            .put(fn("press_system", "সিস্টেম বোতাম।", mapOf("button" to p("STRING", "back, home, recents, notifications, অথবা quick_settings")), listOf("button")))
            .put(fn("open_app", "নাম দিয়ে অ্যাপ খোলে।", mapOf("name" to p("STRING", "অ্যাপের নাম")), listOf("name")))
            .put(fn("open_url", "একটি http/https লিংক খোলে (যেমন ইউটিউব সার্চ: https://www.youtube.com/results?search_query=শব্দ)।",
                mapOf("url" to p("STRING", "সম্পূর্ণ লিংক")), listOf("url")))
            .put(fn("wait", "কিছুক্ষণ অপেক্ষা করে (পেজ লোডের জন্য)।", mapOf("seconds" to p("NUMBER", "০.৫ থেকে ৫ সেকেন্ড")), listOf("seconds")))
            .put(fn("set_volume", "মিডিয়া ভলিউম সেট করে।", mapOf("level" to p("INTEGER", "০ থেকে ১০০ শতাংশ")), listOf("level")))

        if (rootAvailable) {
            arr.put(fn("wifi_connect", "Root দিয়ে সরাসরি Wi-Fi নেটওয়ার্কে সংযোগ করে।",
                mapOf("ssid" to p("STRING", "নেটওয়ার্কের নাম"), "security" to p("STRING", "open, wpa2 অথবা wpa3"), "password" to p("STRING", "পাসওয়ার্ড")), listOf("ssid")))
            arr.put(fn("set_toggle", "Wi-Fi, ব্লুটুথ, মোবাইল ডেটা, বিমান মোড, লোকেশন (GPS), বা হটস্পট চালু/বন্ধ করে।",
                mapOf("name" to p("STRING", "wifi, bluetooth, mobile_data, airplane, location, অথবা hotspot"), "enabled" to p("BOOLEAN", "চালু = true")), listOf("name", "enabled")))
            arr.put(fn("set_brightness", "স্ক্রিনের উজ্জ্বলতা (০–২৫৫) সেট করে।", mapOf("level" to p("INTEGER", "০–২৫৫")), listOf("level")))
            arr.put(fn("key_event", "ফোনের হার্ডওয়্যার/মিডিয়া কী চাপে।",
                mapOf("key" to p("STRING", "HOME, BACK, CALL, ENDCALL, ENTER, VOLUME_UP, VOLUME_DOWN, MEDIA_PLAY_PAUSE, MEDIA_NEXT, MEDIA_PREVIOUS, WAKEUP, SLEEP, APP_SWITCH, TAB, SPACE, DEL, MUTE, SCREENSHOT")), listOf("key")))
            arr.put(fn("force_stop_app", "একটি অ্যাপ জোর করে বন্ধ করে।", mapOf("package" to p("STRING", "প্যাকেজ নাম, যেমন com.google.android.youtube")), listOf("package")))
            arr.put(fn("clear_app_cache", "র‍্যাম ফ্রি করতে ও ক্যাশ পরিষ্কার করতে ব্যবহার করো। package='all' দিলে সব অ্যাপের ক্যাশ পরিষ্কার হয়।",
                mapOf("package" to p("STRING", "প্যাকেজ নাম অথবা all")), listOf("package")))
            arr.put(fn("root_tap", "Root দিয়ে সরাসরি (x, y) স্থানাঙ্কে ট্যাপ করে (গেম বা সুরক্ষিত অ্যাপে যেখানে সাধারণ ট্যাপ কাজ করে না)।",
                mapOf("x" to p("INTEGER", "x"), "y" to p("INTEGER", "y")), listOf("x", "y")))
            arr.put(fn("root_swipe", "Root দিয়ে সরাসরি সোয়াইপ করে।",
                mapOf("x1" to p("INTEGER", "x1"), "y1" to p("INTEGER", "y1"), "x2" to p("INTEGER", "x2"), "y2" to p("INTEGER", "y2"), "duration" to p("INTEGER", "সময় (মি.সে.)")), listOf("x1", "y1", "x2", "y2")))
            arr.put(fn("root_type", "Root দিয়ে সরাসরি কীবোর্ড ইনপুট দেয়।", mapOf("text" to p("STRING", "ইংরেজি/সংখ্যা টেক্সট")), listOf("text")))
            arr.put(fn("take_screenshot", "Root দিয়ে তাৎক্ষণিক স্ক্রিনশট নিয়ে গ্যালারিতে সেভ করে।"))
            arr.put(fn("power_control", "ফোন লক, রিবুট, রিকভারি মোড বা শাটডাউন করে।",
                mapOf("mode" to p("STRING", "lock, reboot, recovery, bootloader, অথবা shutdown")), listOf("mode")))
            arr.put(fn("run_root_shell", "হাই-লেভেল সিস্টেম কন্ট্রোলের জন্য সরাসরি অ্যান্ড্রয়েড রুট শেল কমান্ড (settings, cmd, svc, am, pm, wm, dumpsys, getprop, setprop, free, df) চালায়।",
                mapOf("command" to p("STRING", "রুট শেল কমান্ড")), listOf("command")))
            arr.put(fn("root_info", "ডিভাইসের বিস্তারিত তথ্য পড়ে।", mapOf("kind" to p("STRING", "battery, apps, অথবা perf (RAM/Storage)")), listOf("kind")))
        }
        return arr
    }
}
