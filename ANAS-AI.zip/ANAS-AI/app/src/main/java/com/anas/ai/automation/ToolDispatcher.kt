package com.anas.ai.automation

import com.anas.ai.root.RootOperation
import org.json.JSONArray
import org.json.JSONObject

/** Gemini-কে জানানো ফাংশন ডিক্লারেশন। */
object ToolDispatcher {

    private fun param(type: String, description: String) =
        JSONObject().put("type", type).put("description", description)

    private fun fn(name: String, description: String, props: Map<String, JSONObject> = emptyMap(), required: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", description)
        if (props.isNotEmpty()) {
            val p = JSONObject()
            props.forEach { (k, v) -> p.put(k, v) }
            val schema = JSONObject().put("type", "OBJECT").put("properties", p)
            if (required.isNotEmpty()) schema.put("required", JSONArray(required))
            o.put("parameters", schema)
        }
        return o
    }

    fun declarations(rootAvailable: Boolean): JSONArray {
        val arr = JSONArray()
            .put(fn("get_screen", "বর্তমানে দৃশ্যমান স্ক্রিনের লেখা ও বোতামের তালিকা পড়ে।"))
            .put(fn("tap_text", "স্ক্রিনে দেখা লেখা/লেবেল অনুযায়ী ট্যাপ করে।", mapOf("text" to param("STRING", "বোতাম বা লেখার লেবেল")), listOf("text")))
            .put(fn("long_press_text", "লেবেল অনুযায়ী লং-প্রেস করে।", mapOf("text" to param("STRING", "লেবেল")), listOf("text")))
            .put(fn("scroll", "স্ক্রল করে।", mapOf("direction" to param("STRING", "down অথবা up")), listOf("direction")))
            .put(fn("type_text", "বর্তমান ইনপুট ফিল্ডে লেখে।", mapOf("text" to param("STRING", "যা লিখতে হবে")), listOf("text")))
            .put(fn("press_system", "সিস্টেম বোতাম।", mapOf("button" to param("STRING", "back, home, recents অথবা notifications")), listOf("button")))
            .put(fn("open_app", "নাম দিয়ে অ্যাপ খোলে।", mapOf("name" to param("STRING", "অ্যাপের নাম")), listOf("name")))
        if (rootAvailable) {
            arr.put(
                fn(
                    "root_action",
                    "নির্ধারিত Root অপারেশন। অনুমোদিত operation: ${RootOperation.ALLOWED.joinToString()}। force_stop-এ argument = প্যাকেজ নাম, set_brightness-এ argument = 0–255।",
                    mapOf(
                        "operation" to param("STRING", "অপারেশনের নাম"),
                        "argument" to param("STRING", "প্রয়োজনে আর্গুমেন্ট"),
                    ),
                    listOf("operation"),
                ),
            )
        }
        return arr
    }
}
