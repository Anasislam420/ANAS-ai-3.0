package com.anas.ai.automation

import org.json.JSONArray
import org.json.JSONObject

/** Gemini-কে জানানো ফাংশন ডিক্লারেশন। রিবুট/শাটডাউন/রিসেট/মোছার কোনো টুল ইচ্ছাকৃতভাবে নেই। */
object ToolDispatcher {

    private fun p(type: String, description: String) = JSONObject().put("type", type).put("description", description)

    private fun fn(name: String, description: String, props: Map<String, JSONObject> = emptyMap(), required: List<String> = emptyList()): JSONObject {
        val o = JSONObject().put("name", name).put("description", description)
        if (props.isNotEmpty()) {
            val pr = JSONObject()
            props.forEach { (k, v) -> pr.put(k, v) }
            val schema = JSONObject().put("type", "OBJECT").put("properties", pr)
            if (required.isNotEmpty()) schema.put("required", JSONArray(required))
            o.put("parameters", schema)
        }
        return o
    }

    val ROOT_TOOLS = setOf("wifi_connect", "set_toggle", "set_brightness", "key_event", "force_stop_app", "root_info")

    fun declarations(rootAvailable: Boolean): JSONArray {
        val arr = JSONArray()
            .put(fn("get_screen", "বর্তমান স্ক্রিনের দৃশ্যমান লেখা, বোতাম ও তাদের center স্থানাঙ্ক পড়ে। প্রতিটি কাজের পর ফল যাচাইয়ে ব্যবহার করো।"))
            .put(fn("tap_text", "স্ক্রিনে দেখা লেখা/লেবেল অনুযায়ী ট্যাপ করে।", mapOf("text" to p("STRING", "বোতাম বা লেখার লেবেল")), listOf("text")))
            .put(fn("long_press_text", "লেবেল অনুযায়ী লং-প্রেস করে।", mapOf("text" to p("STRING", "লেবেল")), listOf("text")))
            .put(fn("tap_xy", "স্ক্রিনের নির্দিষ্ট পিক্সেল স্থানাঙ্কে ট্যাপ করে (get_screen-এর center থেকে)। tap_text কাজ না করলে ব্যবহার করো।",
                mapOf("x" to p("INTEGER", "x"), "y" to p("INTEGER", "y")), listOf("x", "y")))
            .put(fn("scroll", "তালিকা/পেজ স্ক্রল করে।", mapOf("direction" to p("STRING", "down (নিচে) অথবা up (উপরে)")), listOf("direction")))
            .put(fn("swipe", "আঙুল টেনে সোয়াইপ করে।", mapOf("direction" to p("STRING", "আঙুল যেদিকে সরবে: up, down, left, right")), listOf("direction")))
            .put(fn("type_text", "বর্তমান ইনপুট ঘরে লেখে (ঘর না পেলে কয়েকবার অপেক্ষা করে)। submit=true হলে Enter/Search চাপে। পাসওয়ার্ড ঘরে লিখতে ব্যবহারকারীর সম্মতি নেওয়া হয়।",
                mapOf("text" to p("STRING", "যা লিখতে হবে"), "submit" to p("BOOLEAN", "লেখার পর Enter/Search চাপবে কি না")), listOf("text")))
            .put(fn("press_system", "সিস্টেম বোতাম।", mapOf("button" to p("STRING", "back, home, recents অথবা notifications")), listOf("button")))
            .put(fn("open_app", "নাম দিয়ে অ্যাপ খোলে।", mapOf("name" to p("STRING", "অ্যাপের নাম")), listOf("name")))
            .put(fn("open_url", "একটি http/https লিংক খোলে (যেমন ইউটিউব সার্চ: https://www.youtube.com/results?search_query=শব্দ)। সার্চের দ্রুত ও নির্ভরযোগ্য উপায়।",
                mapOf("url" to p("STRING", "সম্পূর্ণ লিংক")), listOf("url")))
            .put(fn("wait", "কিছুক্ষণ অপেক্ষা করে (পেজ লোডের জন্য)।", mapOf("seconds" to p("NUMBER", "০.৫ থেকে ৫ সেকেন্ড")), listOf("seconds")))
            .put(fn("set_volume", "মিডিয়া ভলিউম সেট করে।", mapOf("level" to p("INTEGER", "০ থেকে ১০০ শতাংশ")), listOf("level")))
        if (rootAvailable) {
            arr.put(fn("wifi_connect", "Root দিয়ে সরাসরি Wi-Fi নেটওয়ার্কে সংযোগ করে (সবচেয়ে নির্ভরযোগ্য)। পাসওয়ার্ড জোরে পুনরাবৃত্তি করো না।",
                mapOf("ssid" to p("STRING", "নেটওয়ার্কের নাম"), "security" to p("STRING", "open, wpa2 অথবা wpa3 (ডিফল্ট wpa2)"), "password" to p("STRING", "পাসওয়ার্ড (open হলে খালি)")), listOf("ssid")))
            arr.put(fn("set_toggle", "Wi-Fi, ব্লুটুথ, মোবাইল ডেটা বা বিমান মোড চালু/বন্ধ করে।",
                mapOf("name" to p("STRING", "wifi, bluetooth, mobile_data অথবা airplane"), "enabled" to p("BOOLEAN", "চালু = true")), listOf("name", "enabled")))
            arr.put(fn("set_brightness", "স্ক্রিনের উজ্জ্বলতা (০–২৫৫) সেট করে।", mapOf("level" to p("INTEGER", "০–২৫৫")), listOf("level")))
            arr.put(fn("key_event", "ফোনের কী চাপে।", mapOf("key" to p("STRING", "HOME, BACK, ENTER, VOLUME_UP, VOLUME_DOWN, MEDIA_PLAY_PAUSE, MEDIA_NEXT, MEDIA_PREVIOUS, WAKEUP, SLEEP (স্ক্রিন বন্ধ), APP_SWITCH")), listOf("key")))
            arr.put(fn("force_stop_app", "একটি অ্যাপ জোর করে বন্ধ করে (নিশ্চিতকরণ লাগে)।", mapOf("package" to p("STRING", "প্যাকেজ নাম, যেমন com.google.android.youtube")), listOf("package")))
            arr.put(fn("root_info", "ডিভাইসের তথ্য পড়ে।", mapOf("kind" to p("STRING", "battery অথবা apps")), listOf("kind")))
        }
        return arr
    }
}
