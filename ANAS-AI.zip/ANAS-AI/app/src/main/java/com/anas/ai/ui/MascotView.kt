package com.anas.ai.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.ColorUtils
import com.anas.ai.core.AssistantState
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.cos

/** ভাসমান ছোট কার্টুন ম্যাস্কট: চোখ পিটপিট করে, কথা বলার সময় মুখ নড়ে, ভাবার সময় চোখ ঘোরে। */
class MascotView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0,
) : View(context, attrs, defStyle) {

    var state: AssistantState = AssistantState.OFFLINE
    var level: Float = 0f

    private var smooth = 0f
    private var phase = 0f
    private var frame = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val density = resources.displayMetrics.density

    private fun colorFor(s: AssistantState) = when (s) {
        AssistantState.OFFLINE -> 0xFF64748B.toInt()
        AssistantState.CONNECTING -> 0xFFFBBF24.toInt()
        AssistantState.LISTENING -> 0xFF22D3EE.toInt()
        AssistantState.THINKING -> 0xFFA78BFA.toInt()
        AssistantState.SPEAKING -> 0xFFF472B6.toInt()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        smooth += (level - smooth) * 0.3f
        phase += 0.05f
        frame++
        val cx = width / 2f
        val cy = height / 2f
        val bounce = if (state == AssistantState.SPEAKING) smooth * 0.10f else 0f
        val r = min(width, height) * 0.36f * (1f + 0.03f * sin(phase) + bounce)
        val color = colorFor(state)

        // আভা
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, r * 1.35f,
            intArrayOf(ColorUtils.setAlphaComponent(color, 140), ColorUtils.setAlphaComponent(color, 0)),
            null, Shader.TileMode.CLAMP,
        )
        canvas.drawCircle(cx, cy, r * 1.35f, paint)
        // শরীর
        paint.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.35f, r * 1.4f,
            intArrayOf(ColorUtils.blendARGB(color, Color.WHITE, 0.55f), color, ColorUtils.blendARGB(color, Color.BLACK, 0.5f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP,
        )
        canvas.drawCircle(cx, cy, r, paint)
        paint.shader = null

        // চোখ
        val blinkPos = frame % 200
        val open = when {
            state == AssistantState.OFFLINE -> 0.12f
            blinkPos < 8 -> (abs(blinkPos - 4) / 4f).coerceIn(0.12f, 1f)
            else -> 1f
        }
        val ex = r * 0.38f
        val ey = cy - r * 0.12f
        val ew = r * 0.21f
        val eh = r * 0.27f * open
        for (side in intArrayOf(-1, 1)) {
            val x = cx + side * ex
            paint.color = Color.WHITE
            rect.set(x - ew, ey - eh, x + ew, ey + eh)
            canvas.drawOval(rect, paint)
            if (open > 0.45f) {
                val (px, py) = when (state) {
                    AssistantState.THINKING -> Pair(sin(phase * 2f) * ew * 0.45f, -ew * 0.15f)
                    AssistantState.CONNECTING -> Pair(cos(phase * 3f) * ew * 0.4f, sin(phase * 3f) * ew * 0.4f)
                    AssistantState.LISTENING -> Pair(0f, ew * 0.05f)
                    else -> Pair(0f, 0f)
                }
                paint.color = 0xFF0A0E1A.toInt()
                canvas.drawCircle(x + px, ey + py, ew * 0.55f, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(x + px - ew * 0.18f, ey + py - ew * 0.2f, ew * 0.17f, paint)
            }
        }

        // মুখ
        val my = cy + r * 0.40f
        paint.color = 0xFF0A0E1A.toInt()
        when (state) {
            AssistantState.SPEAKING -> {
                val h = r * (0.06f + 0.34f * smooth)
                rect.set(cx - r * 0.26f, my - h / 2, cx + r * 0.26f, my + h / 2)
                paint.style = Paint.Style.FILL
                canvas.drawOval(rect, paint)
            }
            AssistantState.THINKING -> {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx + r * 0.1f, my, r * 0.07f, paint)
            }
            else -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2.2f * density
                paint.strokeCap = Paint.Cap.ROUND
                rect.set(cx - r * 0.26f, my - r * 0.18f, cx + r * 0.26f, my + r * 0.18f)
                if (state == AssistantState.OFFLINE) canvas.drawLine(cx - r * 0.15f, my, cx + r * 0.15f, my, paint)
                else canvas.drawArc(rect, 20f, 140f, false, paint)
            }
        }
        paint.style = Paint.Style.FILL
        postInvalidateOnAnimation()
    }
}
