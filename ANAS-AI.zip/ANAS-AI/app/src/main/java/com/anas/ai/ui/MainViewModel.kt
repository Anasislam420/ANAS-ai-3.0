package com.anas.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.anas.ai.AnasApp

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val engine = (app as AnasApp).engine
    val state = engine.state
    val level = engine.level
    val messages = engine.repo.messages
    val error = engine.lastError
    val confirmation = engine.confirmation
    val automationPaused = engine.coordinator.paused

    fun toggleSession() {
        if (state.value == com.anas.ai.core.AssistantState.OFFLINE) engine.startSession() else engine.stopSession()
    }

    fun toggleAutomation() = engine.coordinator.setPaused(!automationPaused.value)
}
