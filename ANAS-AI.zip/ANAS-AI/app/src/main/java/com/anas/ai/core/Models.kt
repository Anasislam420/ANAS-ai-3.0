package com.anas.ai.core

import kotlinx.coroutines.CompletableDeferred

enum class AssistantState { OFFLINE, CONNECTING, LISTENING, THINKING, SPEAKING }

enum class Role { USER, AI, SYSTEM }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val timestamp: Long,
)

enum class Personality(val key: String, val labelBn: String, val voice: String) {
    ASSISTANT("assistant", "সহকারী (স্মার্ট)", "Kore"),
    GIRLFRIEND("girlfriend", "রোমান্টিক (প্রেমিকা মোড)", "Aoede"),
    SONG("song", "গান ও মিউজিক মোড", "Puck"),
    ROOT_PRO("root_pro", "হাই-লেভেল রুট ও টুলস (JARVIS)", "Charon"),
    FRIENDLY("friendly", "বন্ধুসুলভ আড্ডা", "Puck"),
    PROFESSIONAL("professional", "পেশাদার", "Charon");

    companion object {
        fun fromKey(key: String?): Personality = entries.firstOrNull { it.key == key } ?: ASSISTANT
    }
}

enum class RootStatus { UNKNOWN, NOT_AVAILABLE, DENIED, GRANTED }

/** ঝুঁকিপূর্ণ কাজের আগে ব্যবহারকারীর নিশ্চিতকরণ। */
class Confirmation(val message: String) {
    val result = CompletableDeferred<Boolean>()
}
