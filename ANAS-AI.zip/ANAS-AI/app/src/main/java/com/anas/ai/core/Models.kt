package com.anas.ai.core

import kotlinx.coroutines.CompletableDeferred

enum class AssistantState { OFFLINE, CONNECTING, LISTENING, THINKING, SPEAKING }

enum class Role { USER, AI, SYSTEM }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val timestamp: Long,
)

enum class Personality(val key: String, val labelBn: String, val voice: String) {
    ASSISTANT("assistant", "সহকারী", "Kore"),
    PROFESSIONAL("professional", "পেশাদার", "Charon"),
    FRIENDLY("friendly", "বন্ধুসুলভ", "Puck"),
    GIRLFRIEND("girlfriend", "প্রেমিকা (গার্লফ্রেন্ড)", "Aoede");

    companion object {
        fun fromKey(key: String?): Personality = entries.firstOrNull { it.key == key } ?: ASSISTANT
    }
}

enum class RootStatus { UNKNOWN, NOT_AVAILABLE, DENIED, GRANTED }

/** ঝুঁকিপূর্ণ কাজের আগে ব্যবহারকারীর নিশ্চিতকরণ। */
class Confirmation(val message: String) {
    val result = CompletableDeferred<Boolean>()
}
