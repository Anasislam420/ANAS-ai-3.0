package com.anas.ai.root

/**
 * Root-এ চালানো যায় এমন নির্দিষ্ট (allowlisted) অপারেশন। AI-এর দেওয়া কাঁচা shell কমান্ড কখনো su-তে যায় না;
 * শুধু যাচাই করা আর্গুমেন্ট দিয়ে নির্ধারিত টেমপ্লেট থেকে কমান্ড তৈরি হয়।
 */
sealed class RootOperation {
    abstract val command: String
    abstract val requiresConfirmation: Boolean
    abstract fun describeBn(): String

    data object BatteryInfo : RootOperation() {
        override val command = "dumpsys battery"
        override val requiresConfirmation = false
        override fun describeBn() = "ব্যাটারির তথ্য পড়া"
    }

    data object ListUserApps : RootOperation() {
        override val command = "pm list packages -3"
        override val requiresConfirmation = false
        override fun describeBn() = "ইনস্টল করা অ্যাপের তালিকা দেখা"
    }

    data class ForceStop(val pkg: String) : RootOperation() {
        override val command get() = "am force-stop $pkg"
        override val requiresConfirmation = true
        override fun describeBn() = "\"$pkg\" অ্যাপটি জোর করে বন্ধ করা"
    }

    data class SetBrightness(val level: Int) : RootOperation() {
        override val command get() = "settings put system screen_brightness $level"
        override val requiresConfirmation = true
        override fun describeBn() = "স্ক্রিনের উজ্জ্বলতা $level (০–২৫৫) করা"
    }

    data object Reboot : RootOperation() {
        override val command = "reboot"
        override val requiresConfirmation = true
        override fun describeBn() = "ডিভাইস রিবুট করা"
    }

    companion object {
        private val PACKAGE = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")

        val ALLOWED = listOf("battery_info", "list_user_apps", "force_stop", "set_brightness", "reboot")

        /** অবৈধ নাম বা আর্গুমেন্ট হলে null। */
        fun parse(operation: String, argument: String?): RootOperation? = when (operation) {
            "battery_info" -> BatteryInfo
            "list_user_apps" -> ListUserApps
            "force_stop" -> argument?.trim()?.takeIf { it.length <= 150 && PACKAGE.matches(it) }?.let { ForceStop(it) }
            "set_brightness" -> argument?.trim()?.toIntOrNull()?.takeIf { it in 0..255 }?.let { SetBrightness(it) }
            "reboot" -> Reboot
            else -> null
        }
    }
}
