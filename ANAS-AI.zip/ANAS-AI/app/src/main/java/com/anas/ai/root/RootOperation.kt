package com.anas.ai.root

/**
 * Root-এ চালানো যায় এমন নির্দিষ্ট (allowlisted) অপারেশন। AI-এর দেওয়া কাঁচা shell কমান্ড কখনো su-তে যায় না;
 * যাচাই করা আর্গুমেন্ট দিয়ে নির্ধারিত টেমপ্লেট থেকে কমান্ড তৈরি হয়, এবং স্ট্রিং আর্গুমেন্ট সবসময় single-quote escape করা হয়।
 * ইচ্ছাকৃতভাবে নেই: রিবুট/শাটডাউন, ফ্যাক্টরি রিসেট, ফাইল/অ্যাপ মোছা, ফ্ল্যাশ, সিস্টেম সেটিংস বদল, ইত্যাদি।
 */
sealed class RootOperation {
    abstract val command: String
    abstract val requiresConfirmation: Boolean
    abstract fun describeBn(): String

    data object BatteryInfo : RootOperation() {
        override val command = "dumpsys battery"
        override val requiresConfirmation = false
        override fun describeBn() = "ব্যাটারির তথ্য পড়া"
    }

    data object ListUserApps : RootOperation() {
        override val command = "pm list packages -3"
        override val requiresConfirmation = false
        override fun describeBn() = "ইনস্টল করা অ্যাপের তালিকা দেখা"
    }

    data class ForceStop(val pkg: String) : RootOperation() {
        override val command get() = "am force-stop $pkg"
        override val requiresConfirmation = true
        override fun describeBn() = "\"$pkg\" অ্যাপটি জোর করে বন্ধ করা"
    }

    data class SetBrightness(val level: Int) : RootOperation() {
        override val command get() =
            "settings put system screen_brightness_mode 0; settings put system screen_brightness $level"
        override val requiresConfirmation = false
        override fun describeBn() = "উজ্জ্বলতা $level (০–২৫৫) করা"
    }

    enum class ToggleKind(val key: String, val bn: String) {
        WIFI("wifi", "Wi-Fi"),
        BLUETOOTH("bluetooth", "ব্লুটুথ"),
        MOBILE_DATA("mobile_data", "মোবাইল ডেটা"),
        AIRPLANE("airplane", "বিমান মোড"),
    }

    data class Toggle(val kind: ToggleKind, val on: Boolean) : RootOperation() {
        override val command: String get() {
            val verb = if (on) "enable" else "disable"
            return when (kind) {
                ToggleKind.WIFI -> "svc wifi $verb"
                ToggleKind.BLUETOOTH -> "svc bluetooth $verb"
                ToggleKind.MOBILE_DATA -> "svc data $verb"
                ToggleKind.AIRPLANE -> "cmd connectivity airplane-mode $verb"
            }
        }
        // সংযোগ কেটে দিতে পারে এমন পরিবর্তনে নিশ্চিতকরণ
        override val requiresConfirmation get() =
            (kind == ToggleKind.AIRPLANE && on) || (!on && (kind == ToggleKind.WIFI || kind == ToggleKind.MOBILE_DATA))
        override fun describeBn() = "${kind.bn} ${if (on) "চালু" else "বন্ধ"} করা"
    }

    data class WifiConnect(val ssid: String, val security: String, val password: String) : RootOperation() {
        override val command get() =
            if (security == "open") "cmd wifi connect-network ${shq(ssid)} open"
            else "cmd wifi connect-network ${shq(ssid)} $security ${shq(password)}"
        override val requiresConfirmation = true
        override fun describeBn() = "Wi-Fi \"$ssid\" নেটওয়ার্কে সংযোগ করা"
        override fun toString() = "WifiConnect(ssid=$ssid, security=$security)" // পাসওয়ার্ড কখনো লগে নয়
    }

    data class KeyEvent(val code: Int, val name: String) : RootOperation() {
        override val command get() = "input keyevent $code"
        override val requiresConfirmation = false
        override fun describeBn() = "$name কী চাপা"
    }

    data class OpenUrl(val url: String) : RootOperation() {
        override val command get() = "am start -a android.intent.action.VIEW -d ${shq(url)}"
        override val requiresConfirmation = false
        override fun describeBn() = "লিংক খোলা"
    }

    data class LaunchApp(val pkg: String) : RootOperation() {
        override val command get() = "monkey -p $pkg -c android.intent.category.LAUNCHER 1"
        override val requiresConfirmation = false
        override fun describeBn() = "\"$pkg\" অ্যাপ খোলা"
    }

    companion object {
        private val PACKAGE = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")
        private val URL = Regex("^https?://[\\x21-\\x7E]+$")
        private val CTRL = Regex("[\\p{Cntrl}]")

        private val KEYS = mapOf(
            "HOME" to 3, "BACK" to 4, "ENTER" to 66, "VOLUME_UP" to 24, "VOLUME_DOWN" to 25,
            "MEDIA_PLAY_PAUSE" to 85, "MEDIA_NEXT" to 87, "MEDIA_PREVIOUS" to 88,
            "WAKEUP" to 224, "SLEEP" to 223, "APP_SWITCH" to 187,
        )

        /** single-quote escape: ' → '\'' */
        fun shq(s: String): String = "'" + s.replace("'", "'\\''") + "'"

        /** স্পেস/বাংলা ইত্যাদি non-ASCII অক্ষর percent-encode করে (ইউটিউব সার্চ URL-এর জন্য)। */
        fun normalizeUrl(raw: String): String = buildString {
            for (b in raw.trim().toByteArray(Charsets.UTF_8)) {
                val v = b.toInt() and 0xFF
                if (v in 33..126) append(v.toChar()) else append("%%%02X".format(v))
            }
        }

        /** অবৈধ নাম বা আর্গুমেন্ট হলে null। */
        fun parse(operation: String, args: Map<String, String> = emptyMap()): RootOperation? {
            fun a(k: String) = args[k]?.trim().orEmpty()
            return when (operation) {
                "battery_info" -> BatteryInfo
                "list_user_apps" -> ListUserApps
                "force_stop" -> a("package").takeIf { it.length <= 150 && PACKAGE.matches(it) }?.let { ForceStop(it) }
                "launch_app" -> a("package").takeIf { it.length <= 150 && PACKAGE.matches(it) }?.let { LaunchApp(it) }
                "set_brightness" -> a("level").toIntOrNull()?.takeIf { it in 0..255 }?.let { SetBrightness(it) }
                "set_wifi", "set_bluetooth", "set_mobile_data", "set_airplane" -> {
                    val kind = ToggleKind.entries.first { "set_" + it.key == operation }
                    val on = when (a("enabled").lowercase()) {
                        "true" -> true
                        "false" -> false
                        else -> return null
                    }
                    Toggle(kind, on)
                }
                "wifi_connect" -> {
                    val ssid = args["ssid"].orEmpty()
                    val sec = a("security").lowercase().ifEmpty { "wpa2" }
                    val pw = args["password"].orEmpty()
                    if (ssid.isEmpty() || ssid.toByteArray().size > 32 || CTRL.containsMatchIn(ssid)) return null
                    if (sec !in listOf("open", "wpa2", "wpa3")) return null
                    if (sec != "open" && (pw.length !in 8..63 || CTRL.containsMatchIn(pw))) return null
                    WifiConnect(ssid, sec, pw)
                }
                "key_event" -> {
                    val name = a("key").uppercase()
                    KEYS[name]?.let { KeyEvent(it, name) }
                }
                "open_url" -> a("url").takeIf { it.length <= 1000 && URL.matches(it) }?.let { OpenUrl(it) }
                else -> null
            }
        }
    }
}
