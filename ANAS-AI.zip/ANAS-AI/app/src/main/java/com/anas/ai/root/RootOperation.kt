package com.anas.ai.root

/**
 * হাই-লেভেল ও নিরাপদ Root অপারেশন ইঞ্জিন।
 * স্ট্রিং আর্গুমেন্ট সবসময় single-quote escape করা হয় এবং বিপজ্জনক শেল ইনজেকশন প্রতিরোধ করা হয়।
 */
sealed class RootOperation {
    abstract val command: String
    abstract val requiresConfirmation: Boolean
    abstract fun describeBn(): String

    data object BatteryInfo : RootOperation() {
        override val command = "dumpsys battery"
        override val requiresConfirmation = false
        override fun describeBn() = "ব্যাটারির তথ্য পড়া"
    }

    data object ListUserApps : RootOperation() {
        override val command = "pm list packages -3"
        override val requiresConfirmation = false
        override fun describeBn() = "ইনস্টল করা অ্যাপের তালিকা দেখা"
    }

    data object SystemPerfInfo : RootOperation() {
        override val command = "free -m; df -h /data; getprop ro.product.model"
        override val requiresConfirmation = false
        override fun describeBn() = "র‍্যাম ও স্টোরেজ তথ্য পড়া"
    }

    data class ForceStop(val pkg: String) : RootOperation() {
        override val command get() = "am force-stop $pkg"
        override val requiresConfirmation = true
        override fun describeBn() = "\"$pkg\" অ্যাপটি জোর করে বন্ধ করা"
    }

    data class ClearCache(val pkg: String) : RootOperation() {
        override val command get() = if (pkg == "all") "pm trim-caches 999G" else "pm trim-caches 999G; am kill $pkg"
        override val requiresConfirmation = false
        override fun describeBn() = "ক্যাশ ও ব্যাকগ্রাউন্ড প্রসেস পরিষ্কার করা ($pkg)"
    }

    data class DirectCall(val number: String) : RootOperation() {
        override val command get() = "am start -a android.intent.action.CALL -d tel:${shq(number)}"
        override val requiresConfirmation = false
        override fun describeBn() = "$number নাম্বারে সরাসরি কল করা"
    }

    data class RootTap(val x: Int, val y: Int) : RootOperation() {
        override val command get() = "input tap $x $y"
        override val requiresConfirmation = false
        override fun describeBn() = "স্ক্রিনের ($x, $y) স্থানাঙ্কে রুট ট্যাপ"
    }

    data class RootSwipe(val x1: Int, val y1: Int, val x2: Int, val y2: Int, val duration: Int) : RootOperation() {
        override val command get() = "input swipe $x1 $y1 $x2 $y2 $duration"
        override val requiresConfirmation = false
        override fun describeBn() = "রুট সোয়াইপ ($x1,$y1 → $x2,$y2)"
    }

    data class RootText(val text: String) : RootOperation() {
        override val command get() = "input text ${shq(text.replace(" ", "%s"))}"
        override val requiresConfirmation = false
        override fun describeBn() = "রুট দিয়ে টেক্সট টাইপ করা"
    }

    data class TakeScreenshot(val path: String) : RootOperation() {
        override val command get() = "screencap -p ${shq(path)}"
        override val requiresConfirmation = false
        override fun describeBn() = "স্ক্রিনশট নেওয়া ($path)"
    }

    data class PowerControl(val mode: String) : RootOperation() {
        override val command get() = when (mode) {
            "reboot" -> "svc power reboot"
            "recovery" -> "svc power reboot recovery"
            "bootloader" -> "svc power reboot bootloader"
            "shutdown" -> "svc power shutdown"
            else -> "input keyevent 26"
        }
        override val requiresConfirmation = true
        override fun describeBn() = "পাওয়ার অ্যাকশন: $mode"
    }

    data class CustomShell(val rawCmd: String) : RootOperation() {
        override val command get() = rawCmd
        override val requiresConfirmation = false
        override fun describeBn() = "হাই-লেভেল রুট কমান্ড: $rawCmd"
    }

    data class SetBrightness(val level: Int) : RootOperation() {
        override val command get() =
            "settings put system screen_brightness_mode 0; settings put system screen_brightness $level"
        override val requiresConfirmation = false
        override fun describeBn() = "উজ্জ্বলতা $level (০–২৫৫) করা"
    }

    enum class ToggleKind(val key: String, val bn: String) {
        WIFI("wifi", "Wi-Fi"),
        BLUETOOTH("bluetooth", "ব্লুটুথ"),
        MOBILE_DATA("mobile_data", "মোবাইল ডেটা"),
        AIRPLANE("airplane", "বিমান মোড"),
        LOCATION("location", "লোকেশন/GPS"),
        HOTSPOT("hotspot", "হটস্পট"),
        FLASHLIGHT("flashlight", "ফ্ল্যাশলাইট"),
    }

    data class Toggle(val kind: ToggleKind, val on: Boolean) : RootOperation() {
        override val command: String get() {
            val verb = if (on) "enable" else "disable"
            return when (kind) {
                ToggleKind.WIFI -> "svc wifi $verb"
                ToggleKind.BLUETOOTH -> "svc bluetooth $verb"
                ToggleKind.MOBILE_DATA -> "svc data $verb"
                ToggleKind.AIRPLANE -> "cmd connectivity airplane-mode $verb"
                ToggleKind.LOCATION -> "settings put secure location_mode ${if (on) 3 else 0}"
                ToggleKind.HOTSPOT -> if (on) "cmd wifi start-softap" else "cmd wifi stop-softap"
                ToggleKind.FLASHLIGHT -> "cmd statusbar expand-settings && input keyevent 4"
            }
        }
        override val requiresConfirmation get() =
            (kind == ToggleKind.AIRPLANE && on) || (!on && (kind == ToggleKind.WIFI || kind == ToggleKind.MOBILE_DATA))
        override fun describeBn() = "${kind.bn} ${if (on) "চালু" else "বন্ধ"} করা"
    }

    data class WifiConnect(val ssid: String, val security: String, val password: String) : RootOperation() {
        override val command get() =
            if (security == "open") "cmd wifi connect-network ${shq(ssid)} open"
            else "cmd wifi connect-network ${shq(ssid)} $security ${shq(password)}"
        override val requiresConfirmation = true
        override fun describeBn() = "Wi-Fi \"$ssid\" নেটওয়ার্কে সংযোগ করা"
        override fun toString() = "WifiConnect(ssid=$ssid, security=$security)"
    }

    data class KeyEvent(val code: Int, val name: String) : RootOperation() {
        override val command get() = "input keyevent $code"
        override val requiresConfirmation = false
        override fun describeBn() = "$name কী চাপা"
    }

    data class OpenUrl(val url: String) : RootOperation() {
        override val command get() = "am start -a android.intent.action.VIEW -d ${shq(url)}"
        override val requiresConfirmation = false
        override fun describeBn() = "লিংক খোলা"
    }

    data class LaunchApp(val pkg: String) : RootOperation() {
        override val command get() = "monkey -p $pkg -c android.intent.category.LAUNCHER 1"
        override val requiresConfirmation = false
        override fun describeBn() = "\"$pkg\" অ্যাপ খোলা"
    }

    companion object {
        private val PACKAGE = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")
        private val PHONE = Regex("^[0-9+*#]{3,20}$")
        private val URL = Regex("^https?://[\\x21-\\x7E]+$")
        private val CTRL = Regex("[\\p{Cntrl}]")
        private val ALLOWED_SHELL_PREFIXES = listOf(
            "settings ", "cmd ", "svc ", "am ", "pm ", "wm ", "input ", "dumpsys ",
            "getprop", "setprop ", "top ", "ps ", "df ", "free", "killall ", "pkill ", "screencap "
        )
        private val FORBIDDEN_SHELL_TOKENS = listOf("rm -rf", "mkfs", "dd if=", "reboot", "wipe", "format")

        private val KEYS = mapOf(
            "HOME" to 3, "BACK" to 4, "CALL" to 5, "ENDCALL" to 6,
            "ENTER" to 66, "VOLUME_UP" to 24, "VOLUME_DOWN" to 25,
            "MEDIA_PLAY_PAUSE" to 85, "MEDIA_NEXT" to 87, "MEDIA_PREVIOUS" to 88,
            "WAKEUP" to 224, "SLEEP" to 223, "APP_SWITCH" to 187,
            "TAB" to 61, "SPACE" to 62, "DEL" to 67, "MUTE" to 164, "SCREENSHOT" to 120
        )

        /** single-quote escape: ' → '\'' */
        fun shq(s: String): String = "'" + s.replace("'", "'\\''") + "'"

        /** স্পেস/বাংলা ইত্যাদি non-ASCII অক্ষর percent-encode করে। */
        fun normalizeUrl(raw: String): String = buildString {
            for (b in raw.trim().toByteArray(Charsets.UTF_8)) {
                val v = b.toInt() and 0xFF
                if (v in 33..126) append(v.toChar()) else append("%%%02X".format(v))
            }
        }

        /** অবৈধ নাম বা আর্গুমেন্ট হলে null। */
        fun parse(operation: String, args: Map<String, String> = emptyMap()): RootOperation? {
            fun a(k: String) = args[k]?.trim().orEmpty()
            return when (operation) {
                "battery_info" -> BatteryInfo
                "list_user_apps" -> ListUserApps
                "system_perf" -> SystemPerfInfo
                "force_stop" -> a("package").takeIf { it.length <= 150 && PACKAGE.matches(it) }?.let { ForceStop(it) }
                "clear_cache" -> {
                    val p = a("package").ifEmpty { "all" }
                    if (p == "all" || (p.length <= 150 && PACKAGE.matches(p))) ClearCache(p) else null
                }
                "direct_call" -> {
                    val cleaned = a("number").replace(Regex("[\\s()-]"), "")
                    cleaned.takeIf { PHONE.matches(it) }?.let { DirectCall(it) }
                }
                "root_tap" -> {
                    val x = a("x").toIntOrNull() ?: return null
                    val y = a("y").toIntOrNull() ?: return null
                    if (x in 0..10000 && y in 0..10000) RootTap(x, y) else null
                }
                "root_swipe" -> {
                    val x1 = a("x1").toIntOrNull() ?: return null
                    val y1 = a("y1").toIntOrNull() ?: return null
                    val x2 = a("x2").toIntOrNull() ?: return null
                    val y2 = a("y2").toIntOrNull() ?: return null
                    val dur = a("duration").toIntOrNull()?.coerceIn(50, 5000) ?: 300
                    if (x1 in 0..10000 && y1 in 0..10000 && x2 in 0..10000 && y2 in 0..10000) RootSwipe(x1, y1, x2, y2, dur) else null
                }
                "root_text" -> a("text").takeIf { it.isNotEmpty() && it.length <= 500 && !CTRL.containsMatchIn(it) }?.let { RootText(it) }
                "take_screenshot" -> {
                    val path = a("path").ifEmpty { "/sdcard/Pictures/ANAS_Shot_${System.currentTimeMillis()}.png" }
                    if (!CTRL.containsMatchIn(path) && path.startsWith("/sdcard/")) TakeScreenshot(path) else null
                }
                "power_control" -> {
                    val mode = a("mode").lowercase()
                    if (mode in listOf("reboot", "recovery", "bootloader", "shutdown", "lock")) PowerControl(mode) else null
                }
                "custom_shell" -> {
                    val cmd = a("command")
                    val lower = cmd.lowercase()
                    if (cmd.isNotEmpty() && cmd.length <= 600 && !CTRL.containsMatchIn(cmd) &&
                        ALLOWED_SHELL_PREFIXES.any { lower.startsWith(it) } &&
                        FORBIDDEN_SHELL_TOKENS.none { lower.contains(it) }
                    ) CustomShell(cmd) else null
                }
                "launch_app" -> a("package").takeIf { it.length <= 150 && PACKAGE.matches(it) }?.let { LaunchApp(it) }
                "set_brightness" -> a("level").toIntOrNull()?.takeIf { it in 0..255 }?.let { SetBrightness(it) }
                "set_wifi", "set_bluetooth", "set_mobile_data", "set_airplane", "set_location", "set_hotspot", "set_flashlight" -> {
                    val kind = ToggleKind.entries.first { "set_" + it.key == operation }
                    val on = when (a("enabled").lowercase()) {
                        "true" -> true
                        "false" -> false
                        else -> return null
                    }
                    Toggle(kind, on)
                }
                "wifi_connect" -> {
                    val ssid = args["ssid"].orEmpty()
                    val sec = a("security").lowercase().ifEmpty { "wpa2" }
                    val pw = args["password"].orEmpty()
                    if (ssid.isEmpty() || ssid.toByteArray().size > 32 || CTRL.containsMatchIn(ssid)) return null
                    if (sec !in listOf("open", "wpa2", "wpa3")) return null
                    if (sec != "open" && (pw.length !in 8..63 || CTRL.containsMatchIn(pw))) return null
                    WifiConnect(ssid, sec, pw)
                }
                "key_event" -> {
                    val name = a("key").uppercase()
                    KEYS[name]?.let { KeyEvent(it, name) }
                }
                "open_url" -> a("url").takeIf { it.length <= 1000 && URL.matches(it) }?.let { OpenUrl(it) }
                else -> null
            }
        }
    }
}
