package com.anas.ai.automation

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.anas.ai.AnasApp
import com.anas.ai.R
import com.anas.ai.core.AssistantEngine
import com.anas.ai.core.AssistantState
import com.anas.ai.core.Confirmation
import com.anas.ai.ui.MainActivity
import com.anas.ai.ui.MascotView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * অ্যাপ ব্যাকগ্রাউন্ডে থাকলে স্ক্রিনের ওপর ভাসমান ম্যাস্কট + স্ট্যাটাস + থামান বোতাম দেখায়।
 * ঝুঁকিপূর্ণ কাজের নিশ্চিতকরণও এখানেই আসে, যাতে অ্যাপে ফিরতে না হয়।
 * TYPE_ACCESSIBILITY_OVERLAY ব্যবহার করায় আলাদা "অন্য অ্যাপের ওপর দেখানো" অনুমতি লাগে না।
 */
class OverlayController(
    private val svc: AccessibilityService,
    private val engine: AssistantEngine,
    private val app: AnasApp,
) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val dm = svc.resources.displayMetrics
    private fun dp(v: Int) = (v * dm.density).toInt()

    private var bubble: LinearLayout? = null
    private var panel: LinearLayout? = null
    private var mascot: MascotView? = null
    private var chip: TextView? = null
    private var label: String? = null

    fun start() {
        scope.launch {
            combine(engine.state, app.appVisible) { s, visible -> s != AssistantState.OFFLINE && !visible }
                .distinctUntilChanged()
                .collect { if (it) showBubble() else hideBubble() }
        }
        scope.launch { engine.state.collect { mascot?.state = it; updateChip() } }
        scope.launch { engine.level.collect { mascot?.level = it } }
        scope.launch { engine.coordinator.actionLabel.collect { label = it; updateChip() } }
        scope.launch {
            combine(engine.confirmation, app.appVisible) { c, visible -> if (visible) null else c }
                .distinctUntilChanged()
                .collect { showPanel(it) }
        }
    }

    fun stop() {
        scope.cancel()
        hideBubble()
        showPanel(null)
    }

    private fun params(w: Int, h: Int, gravity: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT,
    ).apply { this.gravity = gravity }

    private fun pill(color: Int, radius: Int = 24) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), 0x33FFFFFF)
    }

    private fun stateText(s: AssistantState) = svc.getString(
        when (s) {
            AssistantState.OFFLINE -> R.string.status_offline
            AssistantState.CONNECTING -> R.string.status_connecting
            AssistantState.LISTENING -> R.string.status_listening
            AssistantState.THINKING -> R.string.status_thinking
            AssistantState.SPEAKING -> R.string.status_speaking
        },
    )

    private fun updateChip() {
        chip?.text = label ?: stateText(engine.state.value)
    }

    private fun showBubble() {
        if (bubble != null) return
        val lp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        lp.x = dp(12); lp.y = dp(180)

        val m = MascotView(svc).apply { state = engine.state.value }
        val c = TextView(svc).apply {
            setTextColor(Color.WHITE); textSize = 11f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = pill(0xCC0B1226.toInt(), 14)
        }
        val stop = TextView(svc).apply {
            text = "■"; setTextColor(Color.WHITE); textSize = 11f; gravity = Gravity.CENTER
            background = pill(0xFFF43F5E.toInt(), 14)
            setOnClickListener { engine.stopSession() }
        }
        val row = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(c)
            addView(stop, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginStart = dp(6) })
        }
        val root = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(m, LinearLayout.LayoutParams(dp(76), dp(76)))
            addView(row)
        }
        root.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt()
                        val dy = (e.rawY - sy).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.x = ox + dx; lp.y = oy + dy
                            try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) openApp()
                }
                return true
            }
        })
        try {
            wm.addView(root, lp)
            bubble = root; mascot = m; chip = c
            updateChip()
        } catch (_: Exception) {}
    }

    private fun hideBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null; mascot = null; chip = null
    }

    private fun showPanel(c: Confirmation?) {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        if (c == null) return
        val msg = TextView(svc).apply { text = c.message; setTextColor(Color.WHITE); textSize = 15f }
        fun btn(text: String, color: Int, result: Boolean) = TextView(svc).apply {
            this.text = text; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = pill(color, 20)
            setOnClickListener { c.result.complete(result) }
        }
        val buttons = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END
            addView(btn(svc.getString(R.string.conf_cancel), 0x33FFFFFF, false))
            addView(btn(svc.getString(R.string.conf_allow), 0xFF6366F1.toInt(), true),
                LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
        }
        val card = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            background = pill(0xF2101A33.toInt(), 22)
            addView(msg)
            addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        }
        val lp = params((dm.widthPixels * 0.9f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.y = dp(96)
        try { wm.addView(card, lp); panel = card } catch (_: Exception) {}
    }

    private fun openApp() {
        try {
            svc.startActivity(Intent(svc, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
}
