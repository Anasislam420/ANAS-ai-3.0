package com.anas.ai.core

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** কথোপকথনের ইতিহাস (টাইমস্ট্যাম্পসহ)। ডিভাইসেই JSON হিসেবে সংরক্ষিত, সর্বোচ্চ ২০০টি বার্তা। */
class ConversationRepository(context: Context) {

    private val prefs = context.getSharedPreferences("anas_history", Context.MODE_PRIVATE)
    private val lock = Any()
    private val _messages = MutableStateFlow(load())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private var openRole: Role? = null
    private var nextId = (_messages.value.maxOfOrNull { it.id } ?: 0L) + 1

    /** ট্রান্সক্রিপশনের টুকরো একই টার্নের বার্তায় জুড়ে দেয়। */
    fun stream(role: Role, chunk: String) {
        if (chunk.isEmpty()) return
        synchronized(lock) {
            val list = _messages.value
            val last = list.lastOrNull()
            if (openRole == role && last != null && last.role == role) {
                _messages.value = list.dropLast(1) + last.copy(text = last.text + chunk)
            } else {
                openRole = role
                _messages.value = (list + ChatMessage(nextId++, role, chunk, System.currentTimeMillis())).takeLast(MAX)
            }
        }
    }

    fun endTurn() {
        synchronized(lock) { openRole = null }
        persist()
    }

    fun addSystem(text: String) {
        synchronized(lock) {
            openRole = null
            _messages.value = (_messages.value + ChatMessage(nextId++, Role.SYSTEM, text, System.currentTimeMillis())).takeLast(MAX)
        }
        persist()
    }

    fun clear() {
        synchronized(lock) {
            openRole = null
            _messages.value = emptyList()
        }
        persist()
    }

    private fun persist() {
        val arr = JSONArray()
        _messages.value.forEach {
            arr.put(JSONObject().put("id", it.id).put("r", it.role.name).put("t", it.text).put("ts", it.timestamp))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    private fun load(): List<ChatMessage> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            ChatMessage(o.getLong("id"), Role.valueOf(o.getString("r")), o.getString("t"), o.getLong("ts"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private companion object { const val MAX = 200 }
}
