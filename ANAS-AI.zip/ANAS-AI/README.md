# ANAS AI — বাংলা-প্রথম রিয়েল-টাইম ভয়েস সহকারী (Android)

Package: `com.anas.ai` • Kotlin • MVVM + StateFlow/SharedFlow + Coroutines • OkHttp WebSocket • minSdk 26 • Gradle Kotlin DSL

> **অবস্থা (সততার সঙ্গে):** এই সোর্স একটি পরিবেশে লেখা হয়েছে যেখানে Android SDK, Gradle ডিপেন্ডেন্সি ডাউনলোড ও ডিভাইস/এমুলেটর ছিল না।
> তাই **কম্পাইল, APK বিল্ড, টেস্ট রান বা ডিভাইসে পরীক্ষা এখনো হয়নি।** নিচের "যাচাই তালিকা" অনুযায়ী আপনার মেশিনে ধাপগুলো চালাতে হবে।

## বিল্ড
1. Android Studio (Koala বা নতুন, JDK 17) দিয়ে এই ফোল্ডার খুলুন। Gradle wrapper jar এখানে নেই; Android Studio নিজে Gradle 8.7 ডাউনলোড করবে (অথবা টার্মিনালে `gradle wrapper --gradle-version 8.7`)।
2. Sync হলে: `./gradlew :app:testDebugUnitTest` (ইউনিট টেস্ট), `./gradlew :app:assembleDebug` (APK → `app/build/outputs/apk/debug/`)।
3. Release (R8 + resource shrinking চালু): `./gradlew :app:assembleRelease`। এটি ডিবাগ কী দিয়ে সই করা; প্রকাশের আগে নিজের keystore দিন।
4. ডিভাইস/এমুলেটর থাকলে: `./gradlew :app:connectedDebugAndroidTest`।
5. APK-এর আকার: `ls -l app/build/outputs/apk/release/` — আকার নির্দিষ্ট করে বলা হয়নি, মেপে নিন।

## Gemini API Key কনফিগারেশন
1. Google AI Studio থেকে API কী নিন।
2. অ্যাপ → সেটিংস → কী ও মডেল আইডি দিন → "যাচাই ও সংরক্ষণ করুন"।
3. কী `EncryptedSharedPreferences`-এ (Android Keystore) থাকে; UI-তে শুধু শেষ ৪ অক্ষর দেখায়; লগে কখনো ছাপা হয় না; WebSocket ও যাচাই — দুই ক্ষেত্রেই `x-goog-api-key` header-এ যায়, URL-এ নয়।
4. **মডেল আইডি:** ডিফল্ট `gemini-2.5-flash-native-audio-preview-12-2025`। প্রিভিউ মডেল বন্ধ বা নাম বদল হতে পারে; তাই যাচাই বোতাম মডেল তালিকায় আইডি খোঁজে এবং না পেলে সতর্ক করে। বদলাতে সেটিংসে নতুন আইডি দিন। বর্তমান আইডি Google-এর Live API ডকুমেন্টেশন থেকে নিশ্চিত করুন।

## Accessibility সেটআপ (বাংলায়)
1. অ্যাপ → সেটিংস → "Accessibility সেটিংস খুলুন"।
2. "ডাউনলোড করা অ্যাপ/Installed services"-এ **ANAS AI** → চালু করুন → Android-এর সতর্কতায় নিজে অনুমতি দিন।
3. সেটিংসে অবস্থা "চালু ও সংযুক্ত" দেখালে প্রস্তুত।
4. যেকোনো সময় প্রধান পর্দায় **"অটোমেশন বন্ধ করুন"** চাপলে সব টুল কল প্রত্যাখ্যাত হবে। সেশন বন্ধ করলেও কাজ থামে।
5. Android 13+ এ সাইডলোড করা অ্যাপে "Restricted setting" আটকালে: Settings → Apps → ANAS AI → ⋮ → "Allow restricted settings"।

## Root সেটআপ (ঐচ্ছিক, বাংলায়)
1. রুটেড ডিভাইসে Magisk/KernelSU ইত্যাদি Superuser অ্যাপ থাকতে হবে।
2. সেটিংসে "Root পরীক্ষা করুন" চাপুন → Superuser অ্যাপের অনুমতি দিন → অবস্থা "অনুমোদিত"।
3. "Root অপারেশন ব্যবহারের অনুমতি দিন" সুইচ চালু করুন (ডিফল্ট বন্ধ)।
4. Root না থাকলে/প্রত্যাখ্যাত হলে ভয়েস ও Accessibility স্বাভাবিক চলে; Root টুল AI-কে জানানোই হয় না।
5. **নিরাপত্তা:** AI কাঁচা shell কমান্ড পাঠাতে পারে না; শুধু allowlist: Wi-Fi সংযোগ (`wifi_connect`), Wi-Fi/ব্লুটুথ/মোবাইল ডেটা/বিমান মোড চালু-বন্ধ (`set_toggle`), উজ্জ্বলতা, নির্দিষ্ট কী (HOME, BACK, ENTER, ভলিউম, মিডিয়া ইত্যাদি), লিংক/অ্যাপ খোলা, ব্যাটারি/অ্যাপ তালিকা, অ্যাপ জোর করে বন্ধ। আর্গুমেন্ট যাচাই ও single-quote escape করা হয়।
6. **ইচ্ছাকৃতভাবে নেই:** রিবুট/শাটডাউন, ফ্যাক্টরি রিসেট, ফাইল বা অ্যাপ মোছা, ফ্ল্যাশ, সিস্টেম সেটিংস বদল।
7. নিশ্চিতকরণ লাগে: অ্যাপ জোর করে বন্ধ, Wi-Fi সংযোগ, Wi-Fi/ডেটা বন্ধ করা, বিমান মোড চালু, এবং পাসওয়ার্ড ঘরে লেখা। নিশ্চিতকরণ ভাসমান কার্ডে আসে (৬০ সেকেন্ডে সাড়া না এলে প্রত্যাখ্যাত)।

## ভাসমান ম্যাস্কট
অ্যাপ ব্যাকগ্রাউন্ডে থাকলে স্ক্রিনের ওপর ছোট কার্টুন ম্যাস্কট ভাসে: চোখ পিটপিট করে, কথা বলার সময় মুখ নড়ে, ভাবার সময় চোখ ঘোরে, নিচে বর্তমান কাজ লেখা থাকে ("ট্যাপ করছি…")। টেনে সরানো যায়, ট্যাপে অ্যাপ খোলে, লাল ■ বোতামে সেশন বন্ধ হয়। এটি Accessibility সার্ভিসের overlay, তাই আলাদা অনুমতি লাগে না; Accessibility চালু না থাকলে দেখা যাবে না।

## আর্কিটেকচার
```
core/        AssistantEngine (সেশন, state, reconnect, barge-in, টুল কল), VoiceService (মাইক ফোরগ্রাউন্ড),
             SecureKeyStore, ConversationRepository, SystemPromptBuilder, Models
gemini/      GeminiLiveClient (WebSocket + প্রোটোকল), GeminiKeyValidator
audio/       AudioRecorder (16 kHz PCM16 mono, AEC/NS), AudioPlayer (24 kHz PCM16, flush)
automation/  JarvisAccessibilityService, AutomationCoordinator, AutomationCapabilityChecker, ToolDispatcher
root/        RootOperation (allowlist), RootCommandExecutor, RootCapabilityChecker   ← আলাদা, ঐচ্ছিক
ui/          MainActivity, SettingsActivity, MainViewModel, OrbView (নিজস্ব Canvas Orb, কোনো JS/WebView নেই), MessageAdapter
```
অবস্থা: CONNECTING → LISTENING → THINKING → SPEAKING → (OFFLINE)। সেশন নবায়ন: সার্ভারের `goAway` বা বিচ্ছিন্নতায় `sessionResumption` হ্যান্ডেল দিয়ে এক্সপোনেনশিয়াল ব্যাকঅফে (সর্বোচ্চ ৫ বার) পুনঃসংযোগ।

## ডিপেন্ডেন্সি (ইচ্ছাকৃতভাবে কম)
core-ktx, appcompat, material, recyclerview, activity-ktx, lifecycle, coroutines, okhttp, security-crypto। কোনো native binary, Linux পরিবেশ বা অটোমেশন ফ্রেমওয়ার্ক নেই।

## যাচাই তালিকা (আপনার মেশিনে চালাতে হবে)
| # | কাজ | অবস্থা |
|---|---|---|
| 1 | Gradle dependency resolution | **পরীক্ষা হয়নি** |
| 2 | Kotlin কম্পাইল | **পরীক্ষা হয়নি** |
| 3 | Manifest/resource validation | **পরীক্ষা হয়নি** |
| 4 | API কী save/read (instrumented test লেখা আছে) | **চালানো হয়নি** |
| 5 | Accessibility ঘোষণা ও capability detection | কোড আছে, ডিভাইসে **পরীক্ষা হয়নি** |
| 6 | Root: নেই/প্রত্যাখ্যাত/অনুমোদিত হ্যান্ডলিং | কোড আছে; allowlist/ইনজেকশন ইউনিট টেস্ট লেখা আছে, **চালানো হয়নি** |
| 7 | অটোমেশন ফলাফল যাচাই (screen_changed) | কোড আছে, **পরীক্ষা হয়নি** |
| 8 | ভয়েস সেশন, ডিসকানেক্ট, interruption | **পরীক্ষা হয়নি** |
| 9 | বাংলা প্রম্পট/UI | প্রম্পটের ইউনিট টেস্ট আছে (**চালানো হয়নি**); UI **দেখা হয়নি** |
| 10 | APK তৈরি | **হয়নি** |

## পরিচিত সীমাবদ্ধতা
- Gemini Live প্রোটোকলের ফিল্ড (`sessionResumption`, `contextWindowCompression`, ট্রান্সক্রিপশন, ফাংশন কল) ডকুমেন্টেশন অনুযায়ী লেখা, তবে বাস্তব সার্ভারের বিপরীতে চালানো হয়নি; মডেলভেদে কিছু ফিল্ড অগ্রহণযোগ্য হতে পারে।
- Accessibility সব UI দেখতে পায় না (FLAG_SECURE, ব্যাংকিং অ্যাপ, গেম, কাস্টম ক্যানভাস)। পাসওয়ার্ড ফিল্ড মাস্ক করা হয় ও সেখানে লেখা হয় না। স্থানাঙ্কভিত্তিক জেসচার ইচ্ছাকৃতভাবে নেই।
- Android ১০+ ব্যাকগ্রাউন্ড থেকে অ্যাপ খোলায় বাধা দিতে পারে; `open_app` ব্যর্থ হলে ব্যর্থতাই জানানো হয়।
- ব্যাকগ্রাউন্ডে Root নিশ্চিতকরণ ডায়ালগ দেখাতে অ্যাপ খুলতে হয় (নোটিফিকেশনে জানানো হয়)।
- Barge-in-এ স্পিকারের প্রতিধ্বনি ধরা পড়তে পারে; AEC সব ডিভাইসে নেই, থ্রেশহোল্ড (`0.35`) ডিভাইস অনুযায়ী টিউন করতে হতে পারে। হেডফোন সবচেয়ে ভালো।
- Root-এর সক্ষমতা Android সংস্করণ, SELinux ও ভেন্ডারভেদে আলাদা; অ্যাপ API স্তর ও SELinux অবস্থা দেখায়।
- ইতিহাস ডিভাইসে প্লেইন JSON-এ (কী নয়); ২০০ বার্তার সীমা।

## ভবিষ্যৎ উন্নয়ন
Hilt/Room-এ স্থানান্তর, বিস্তৃত ইউনিট/UI টেস্ট, আরও Root অপারেশন (প্রতিটির আলাদা নিরাপত্তা পর্যালোচনাসহ), ভয়েস বাছাই, Wake-word, স্ক্রিনশট-ভিত্তিক বোঝা।

## Troubleshooting
- **"কী বৈধ নয়: HTTP 400/403":** কী ভুল বা Generative Language API চালু নেই।
- **কী বৈধ কিন্তু "মডেল পাওয়া যায়নি":** মডেল আইডি বদলে তালিকা-সমর্থিত Live মডেল দিন।
- **সংযোগ হয়েই বন্ধ (1008):** সাধারণত মডেল Live সমর্থন করে না বা কী-তে অনুমতি নেই।
- **কথা বললে সাড়া নেই:** মাইক্রোফোন অনুমতি/নোটিফিকেশন অনুমতি দেখুন; ব্যাটারি অপ্টিমাইজেশন ছাড় দিন।
- **অটোমেশন "Accessibility চালু নেই":** সেটিংসে সার্ভিস চালু করুন; কিছু ফোনে অ্যাপ রিস্টার্ট লাগে।
- **Root "প্রত্যাখ্যাত":** Superuser অ্যাপে ANAS AI-কে Grant দিন, তারপর আবার পরীক্ষা করুন।

## GitHub Actions দিয়ে বিল্ড (মোবাইল থেকে)
1. সব ফাইল (`.github/workflows/build.yml` সহ) GitHub রেপোতে আপলোড/পুশ করুন।
2. রেপো → **Actions** → "Build APK" → **Run workflow** (অথবা main-এ পুশ করলেই চলবে)।
3. শেষ হলে রান পেজের নিচে **Artifacts → ANAS-AI-debug-apk** ডাউনলোড করুন; ZIP খুলে APK ইনস্টল করুন।
